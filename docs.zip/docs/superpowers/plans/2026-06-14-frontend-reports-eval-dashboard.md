# Frontend: Reports Export + Evaluation Dashboard — Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.
>
> **REQUIRED SUB-SKILL for all visual/presentational components (Tasks 11, 15, 16, 17, 18):** Use frontend-design:frontend-design to produce the styled implementation. This plan specifies the *contract* (props, behavior, test assertions, structure); the frontend-design skill owns the visual realization (typography, palette, spacing, motion). Do not ship generic AI-gradient styling.

**Goal:** A standalone Vite + React + TS frontend with two pages — a 53-ticker pharma Reports export/download/generate page and an 8-layer fail-closed Evaluation framework dashboard — backed by additive FastAPI endpoints that scan `output/`.

**Architecture:** Frontend calls FastAPI directly (no `/api` prefix); dev via Vite proxy, prod via FastAPI static serving. The dashboard renders declaratively from `data/evalFramework.ts` (structure) + `mock/*.json` (values), so wiring live eval later is a data-source swap. Backend adds a pure filesystem inventory module + three read endpoints.

**Tech Stack:** Python 3 / FastAPI / pytest (backend); Vite + React 18 + TypeScript + React Router + Vitest + React Testing Library (frontend).

**Spec:** `docs/superpowers/specs/2026-06-14-frontend-reports-eval-dashboard-design.md`

---

## File Structure

**Backend (created/modified):**
- Create: `backend/reporting/output_inventory.py` — pure filesystem scan + filename resolver
- Modify: `backend/api.py` — add `/reports`, `/reports/{ticker}/file/{kind}`, `/reports/{ticker}/preview/{page}`, static serving
- Test: `tests/reporting/test_output_inventory.py`, `tests/api/test_reports_endpoints.py`

**Frontend (all created under `frontend/`):**
- `package.json`, `tsconfig.json`, `tsconfig.node.json`, `vite.config.ts`, `vitest.config.ts`, `index.html`, `.env.development`
- `src/main.tsx`, `src/App.tsx`
- `src/api/types.ts`, `src/api/client.ts`, `src/api/runStatus.ts`
- `src/data/universe.ts`, `src/data/evalFramework.ts`
- `src/lib/evalStatus.ts`, `src/lib/reportFilter.ts`
- `src/mock/*.json` (8 artifacts)
- `src/pages/ReportsPage.tsx`, `src/pages/EvalDashboardPage.tsx`
- `src/components/common/Layout.tsx`
- `src/components/reports/{ReportFilters,ReportRow,PreviewPanel,GenerateButton}.tsx`
- `src/components/eval/{PipelineFlow,MaturityToggle,LayerCard,MetricRow,StatusPill}.tsx`
- `src/styles/tokens.css`, `src/styles/global.css`
- Tests colocated as `*.test.ts(x)` next to each unit.

---

## PHASE A — Backend inventory + endpoints (TDD, pytest)

### Task 1: `output_inventory.py` — scanner + extensible resolver

**Files:**
- Create: `backend/reporting/output_inventory.py`
- Test: `tests/reporting/test_output_inventory.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/reporting/test_output_inventory.py
from pathlib import Path
from backend.reporting.output_inventory import scan_report_inventory, ReportInventoryItem


def _universe():
    return [
        {"ticker": "DHG", "company_name": "Duoc Hau Giang", "exchange": "HOSE", "segment": "pharma", "is_mvp": True},
        {"ticker": "IMP", "company_name": "Imexpharm", "exchange": "HOSE", "segment": "pharma", "is_mvp": True},
    ]


def test_scan_reports_present_and_absent(tmp_path: Path):
    out = tmp_path
    (out / "DHG_report.pdf").write_bytes(b"%PDF-1.4 report")
    (out / "DHG_explanation.pdf").write_bytes(b"%PDF-1.4 expl")
    preview = out / "pdf_preview"
    preview.mkdir()
    # intentionally out of lexicographic order to prove numeric sort
    for p in [1, 2, 12, 4, 3]:
        (preview / f"DHG_report_page_{p}.png").write_bytes(b"png")

    items = scan_report_inventory(out, _universe())

    assert [i.ticker for i in items] == ["DHG", "IMP"]  # aligned to universe order
    dhg = items[0]
    assert isinstance(dhg, ReportInventoryItem)
    assert dhg.has_report is True
    assert dhg.has_explanation is True
    assert dhg.preview_pages == [1, 2, 3, 4, 12]  # numeric sort, not string
    assert dhg.report_size > 0
    assert dhg.updated_at is not None

    imp = items[1]
    assert imp.has_report is False
    assert imp.has_explanation is False
    assert imp.preview_pages == []
    assert imp.report_size is None
    assert imp.updated_at is None
```

- [ ] **Step 2: Run test to verify it fails**

Run: `python -m pytest tests/reporting/test_output_inventory.py -v`
Expected: FAIL — `ModuleNotFoundError: backend.reporting.output_inventory`.

- [ ] **Step 3: Write minimal implementation**

```python
# backend/reporting/output_inventory.py
from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path

_PREVIEW_RE = re.compile(r"_report_page_(\d+)\.png$")


@dataclass
class ReportInventoryItem:
    ticker: str
    company_name: str
    exchange: str
    segment: str
    is_mvp: bool
    has_report: bool
    has_explanation: bool
    preview_pages: list[int] = field(default_factory=list)
    report_size: int | None = None
    updated_at: str | None = None


def _resolve_report_files(ticker: str, output_dir: Path) -> dict[str, object]:
    """Single point that maps a ticker to its on-disk artifacts.

    Current convention: ``{TICKER}_report.pdf`` / ``{TICKER}_explanation.pdf`` and
    ``pdf_preview/{TICKER}_report_page_{n}.png``. If a later phase introduces an
    artifact_manifest or run_id-based filenames, change ONLY this function — the
    endpoint shapes and the frontend stay untouched.
    """
    report = output_dir / f"{ticker}_report.pdf"
    explanation = output_dir / f"{ticker}_explanation.pdf"
    preview_dir = output_dir / "pdf_preview"
    pages: list[int] = []
    if preview_dir.is_dir():
        prefix = f"{ticker}_report_page_"
        for f in preview_dir.iterdir():
            if f.name.startswith(prefix):
                m = _PREVIEW_RE.search(f.name)
                if m:
                    pages.append(int(m.group(1)))
    return {
        "report": report if report.is_file() else None,
        "explanation": explanation if explanation.is_file() else None,
        "preview_pages": sorted(pages),  # numeric order
    }


def scan_report_inventory(output_dir: Path, universe: list[dict]) -> list[ReportInventoryItem]:
    items: list[ReportInventoryItem] = []
    for row in universe:
        ticker = str(row["ticker"]).upper()
        resolved = _resolve_report_files(ticker, output_dir)
        report_path = resolved["report"]
        size = report_path.stat().st_size if report_path else None
        updated = (
            datetime.fromtimestamp(report_path.stat().st_mtime, tz=timezone.utc).isoformat()
            if report_path
            else None
        )
        items.append(
            ReportInventoryItem(
                ticker=ticker,
                company_name=str(row.get("company_name", "")),
                exchange=str(row.get("exchange", "")),
                segment=str(row.get("segment", "")),
                is_mvp=bool(row.get("is_mvp", False)),
                has_report=report_path is not None,
                has_explanation=resolved["explanation"] is not None,
                preview_pages=list(resolved["preview_pages"]),
                report_size=size,
                updated_at=updated,
            )
        )
    return items
```

- [ ] **Step 4: Run test to verify it passes**

Run: `python -m pytest tests/reporting/test_output_inventory.py -v`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add backend/reporting/output_inventory.py tests/reporting/test_output_inventory.py
git commit -m "feat(reporting): output inventory scanner with extensible filename resolver"
```

---

### Task 2: Universe loader helper for the API

**Files:**
- Modify: `backend/reporting/output_inventory.py` (add `load_universe`)
- Test: `tests/reporting/test_output_inventory.py` (add a test)

- [ ] **Step 1: Write the failing test**

```python
# append to tests/reporting/test_output_inventory.py
from backend.reporting.output_inventory import load_universe


def test_load_universe_reads_csv(tmp_path: Path):
    csv = tmp_path / "u.csv"
    csv.write_text(
        "ticker,company_name,exchange,segment,is_mvp,notes\n"
        "DHG,Duoc Hau Giang,HOSE,pharma,true,MVP core\n"
        "OPC,OPC Pharma,HOSE,pharma,false,\n",
        encoding="utf-8",
    )
    rows = load_universe(csv)
    assert len(rows) == 2
    assert rows[0]["ticker"] == "DHG"
    assert rows[0]["is_mvp"] is True
    assert rows[1]["is_mvp"] is False
```

- [ ] **Step 2: Run test to verify it fails**

Run: `python -m pytest tests/reporting/test_output_inventory.py::test_load_universe_reads_csv -v`
Expected: FAIL — `ImportError: cannot import name 'load_universe'`.

- [ ] **Step 3: Write minimal implementation**

```python
# add to backend/reporting/output_inventory.py
import csv as _csv


def load_universe(csv_path: Path) -> list[dict]:
    rows: list[dict] = []
    with open(csv_path, newline="", encoding="utf-8") as fh:
        for r in _csv.DictReader(fh):
            rows.append(
                {
                    "ticker": (r.get("ticker") or "").strip().upper(),
                    "company_name": (r.get("company_name") or "").strip(),
                    "exchange": (r.get("exchange") or "").strip(),
                    "segment": (r.get("segment") or "").strip(),
                    "is_mvp": (r.get("is_mvp") or "").strip().lower() == "true",
                    "notes": (r.get("notes") or "").strip(),
                }
            )
    return rows
```

- [ ] **Step 4: Run test to verify it passes**

Run: `python -m pytest tests/reporting/test_output_inventory.py -v`
Expected: PASS (both tests).

- [ ] **Step 5: Commit**

```bash
git add backend/reporting/output_inventory.py tests/reporting/test_output_inventory.py
git commit -m "feat(reporting): load_universe CSV reader"
```

---

### Task 3: `GET /reports` endpoint

**Files:**
- Modify: `backend/api.py`
- Test: `tests/api/test_reports_endpoints.py`

Note: the existing app needs DB on startup; create the test app with `check_schema_on_startup=False`
and stub `store=None` (the new endpoints do not touch the store). Point the endpoints at a temp
output dir and temp universe csv via app state / settings override.

- [ ] **Step 1: Write the failing test**

```python
# tests/api/test_reports_endpoints.py
from pathlib import Path
from fastapi.testclient import TestClient
from backend.api import create_app


def _make_client(tmp_path: Path) -> TestClient:
    out = tmp_path / "output"
    out.mkdir()
    (out / "DHG_report.pdf").write_bytes(b"%PDF-1.4 report")
    (out / "DHG_explanation.pdf").write_bytes(b"%PDF-1.4 expl")
    pv = out / "pdf_preview"
    pv.mkdir()
    (pv / "DHG_report_page_1.png").write_bytes(b"png")

    csv = tmp_path / "universe.csv"
    csv.write_text(
        "ticker,company_name,exchange,segment,is_mvp,notes\n"
        "DHG,Duoc Hau Giang,HOSE,pharma,true,MVP core\n"
        "IMP,Imexpharm,HOSE,pharma,true,MVP core\n",
        encoding="utf-8",
    )
    app = create_app(check_schema_on_startup=False)
    app.state.report_output_dir = out
    app.state.report_universe_csv = csv
    return TestClient(app)


def test_get_reports_lists_universe_with_status(tmp_path):
    client = _make_client(tmp_path)
    resp = client.get("/reports")
    assert resp.status_code == 200
    items = resp.json()["items"]
    assert [i["ticker"] for i in items] == ["DHG", "IMP"]
    assert items[0]["has_report"] is True
    assert items[0]["has_explanation"] is True
    assert items[0]["preview_pages"] == [1]
    assert items[1]["has_report"] is False
```

- [ ] **Step 2: Run test to verify it fails**

Run: `python -m pytest tests/api/test_reports_endpoints.py::test_get_reports_lists_universe_with_status -v`
Expected: FAIL — 404 (route not defined).

- [ ] **Step 3: Write minimal implementation**

Add near the top of `backend/api.py` imports:

```python
from pathlib import Path
from fastapi.responses import FileResponse
from backend.reporting.output_inventory import scan_report_inventory, load_universe
```

Add helpers + route inside `create_app`, before `return app`:

```python
    def _output_dir() -> Path:
        return Path(getattr(app.state, "report_output_dir", None) or "output")

    def _universe_csv() -> Path:
        return Path(
            getattr(app.state, "report_universe_csv", None)
            or "config/dataset/universe/pharma_vn_universe.csv"
        )

    def _universe_index() -> dict[str, dict]:
        return {r["ticker"]: r for r in load_universe(_universe_csv())}

    @app.get("/reports")
    def list_reports() -> dict:
        universe = load_universe(_universe_csv())
        items = scan_report_inventory(_output_dir(), universe)
        return {
            "items": [
                {
                    "ticker": i.ticker,
                    "company_name": i.company_name,
                    "exchange": i.exchange,
                    "segment": i.segment,
                    "is_mvp": i.is_mvp,
                    "has_report": i.has_report,
                    "has_explanation": i.has_explanation,
                    "preview_pages": i.preview_pages,
                    "report_size": i.report_size,
                    "updated_at": i.updated_at,
                }
                for i in items
            ]
        }
```

Also initialize the new state attrs where the app is built (after `app.state.executor = ...`):

```python
    app.state.report_output_dir = None
    app.state.report_universe_csv = None
```

- [ ] **Step 4: Run test to verify it passes**

Run: `python -m pytest tests/api/test_reports_endpoints.py -v`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add backend/api.py tests/api/test_reports_endpoints.py
git commit -m "feat(api): GET /reports inventory endpoint"
```

---

### Task 4: `GET /reports/{ticker}/file/{kind}` + traversal/unknown guards

**Files:**
- Modify: `backend/api.py`
- Test: `tests/api/test_reports_endpoints.py`

- [ ] **Step 1: Write the failing test**

```python
# append to tests/api/test_reports_endpoints.py
def test_get_report_file_ok_and_404(tmp_path):
    client = _make_client(tmp_path)

    ok = client.get("/reports/DHG/file/report")
    assert ok.status_code == 200
    assert ok.headers["content-type"] == "application/pdf"
    assert ok.content.startswith(b"%PDF")

    missing = client.get("/reports/IMP/file/report")  # IMP has no file
    assert missing.status_code == 404


def test_get_report_file_rejects_unknown_ticker_and_bad_kind(tmp_path):
    client = _make_client(tmp_path)
    assert client.get("/reports/ZZZ/file/report").status_code == 404  # not in universe
    assert client.get("/reports/DHG/file/secrets").status_code == 404  # bad kind
    # path traversal attempt in ticker must not escape output dir
    assert client.get("/reports/..%2f..%2fetc/file/report").status_code == 404
```

- [ ] **Step 2: Run test to verify it fails**

Run: `python -m pytest tests/api/test_reports_endpoints.py -k report_file -v`
Expected: FAIL — 404 from missing route / wrong behavior.

- [ ] **Step 3: Write minimal implementation**

Add inside `create_app` before `return app`:

```python
    _FILE_KINDS = {"report": "_report.pdf", "explanation": "_explanation.pdf"}

    @app.get("/reports/{ticker}/file/{kind}")
    def get_report_file(ticker: str, kind: str):
        ticker = ticker.upper()
        if ticker not in _universe_index():
            raise HTTPException(status_code=404, detail="Unknown ticker")
        suffix = _FILE_KINDS.get(kind)
        if suffix is None:
            raise HTTPException(status_code=404, detail="Unknown file kind")
        path = (_output_dir() / f"{ticker}{suffix}").resolve()
        out_root = _output_dir().resolve()
        if out_root not in path.parents or not path.is_file():
            raise HTTPException(status_code=404, detail="File not found")
        return FileResponse(
            path,
            media_type="application/pdf",
            headers={"Content-Disposition": f'inline; filename="{ticker}{suffix}"'},
        )
```

- [ ] **Step 4: Run test to verify it passes**

Run: `python -m pytest tests/api/test_reports_endpoints.py -v`
Expected: PASS (all).

- [ ] **Step 5: Commit**

```bash
git add backend/api.py tests/api/test_reports_endpoints.py
git commit -m "feat(api): serve report/explanation PDFs with ticker + traversal guards"
```

---

### Task 5: `GET /reports/{ticker}/preview/{page}`

**Files:**
- Modify: `backend/api.py`
- Test: `tests/api/test_reports_endpoints.py`

- [ ] **Step 1: Write the failing test**

```python
# append to tests/api/test_reports_endpoints.py
def test_get_preview_png_ok_and_404(tmp_path):
    client = _make_client(tmp_path)
    ok = client.get("/reports/DHG/preview/1")
    assert ok.status_code == 200
    assert ok.headers["content-type"] == "image/png"
    assert client.get("/reports/DHG/preview/999").status_code == 404
    assert client.get("/reports/ZZZ/preview/1").status_code == 404
```

- [ ] **Step 2: Run test to verify it fails**

Run: `python -m pytest tests/api/test_reports_endpoints.py -k preview -v`
Expected: FAIL — route missing.

- [ ] **Step 3: Write minimal implementation**

```python
    @app.get("/reports/{ticker}/preview/{page}")
    def get_report_preview(ticker: str, page: int):
        ticker = ticker.upper()
        if ticker not in _universe_index():
            raise HTTPException(status_code=404, detail="Unknown ticker")
        path = (_output_dir() / "pdf_preview" / f"{ticker}_report_page_{page}.png").resolve()
        out_root = (_output_dir() / "pdf_preview").resolve()
        if out_root not in path.parents or not path.is_file():
            raise HTTPException(status_code=404, detail="Preview not found")
        return FileResponse(path, media_type="image/png")
```

- [ ] **Step 4: Run test to verify it passes**

Run: `python -m pytest tests/api/test_reports_endpoints.py -v`
Expected: PASS (all).

- [ ] **Step 5: Commit**

```bash
git add backend/api.py tests/api/test_reports_endpoints.py
git commit -m "feat(api): serve PDF preview PNG pages"
```

---

## PHASE B — Frontend scaffold + API layer

### Task 6: Scaffold Vite + React + TS + Vitest

**Files:**
- Create: `frontend/package.json`, `frontend/tsconfig.json`, `frontend/tsconfig.node.json`,
  `frontend/vite.config.ts`, `frontend/vitest.config.ts`, `frontend/index.html`,
  `frontend/.env.development`, `frontend/src/main.tsx`, `frontend/src/setupTests.ts`

- [ ] **Step 1: Create `frontend/package.json`**

```json
{
  "name": "pharma-research-frontend",
  "private": true,
  "version": "0.1.0",
  "type": "module",
  "scripts": {
    "dev": "vite",
    "build": "tsc -b && vite build",
    "preview": "vite preview",
    "test": "vitest run",
    "test:watch": "vitest"
  },
  "dependencies": {
    "react": "^18.3.1",
    "react-dom": "^18.3.1",
    "react-router-dom": "^6.26.0"
  },
  "devDependencies": {
    "@testing-library/jest-dom": "^6.4.0",
    "@testing-library/react": "^16.0.0",
    "@testing-library/user-event": "^14.5.0",
    "@types/react": "^18.3.0",
    "@types/react-dom": "^18.3.0",
    "@vitejs/plugin-react": "^4.3.0",
    "jsdom": "^24.1.0",
    "typescript": "^5.5.0",
    "vite": "^5.4.0",
    "vitest": "^2.0.0"
  }
}
```

- [ ] **Step 2: Create config files**

`frontend/vite.config.ts` (proxy `/reports` and `/research` to FastAPI, NO path rewrite):

```ts
import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    proxy: {
      "/reports": { target: "http://localhost:8000", changeOrigin: true },
      "/research": { target: "http://localhost:8000", changeOrigin: true },
    },
  },
});
```

`frontend/vitest.config.ts`:

```ts
import { defineConfig } from "vitest/config";
import react from "@vitejs/plugin-react";

export default defineConfig({
  plugins: [react()],
  test: { environment: "jsdom", globals: true, setupFiles: ["./src/setupTests.ts"] },
});
```

`frontend/tsconfig.json`:

```json
{
  "compilerOptions": {
    "target": "ES2020",
    "useDefineForClassFields": true,
    "lib": ["ES2020", "DOM", "DOM.Iterable"],
    "module": "ESNext",
    "skipLibCheck": true,
    "moduleResolution": "bundler",
    "resolveJsonModule": true,
    "isolatedModules": true,
    "noEmit": true,
    "jsx": "react-jsx",
    "strict": true,
    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "types": ["vitest/globals", "@testing-library/jest-dom"]
  },
  "include": ["src"],
  "references": [{ "path": "./tsconfig.node.json" }]
}
```

`frontend/tsconfig.node.json`:

```json
{
  "compilerOptions": {
    "composite": true,
    "skipLibCheck": true,
    "module": "ESNext",
    "moduleResolution": "bundler",
    "allowSyntheticDefaultImports": true
  },
  "include": ["vite.config.ts", "vitest.config.ts"]
}
```

`frontend/.env.development`:

```
VITE_API_BASE=
```

`frontend/index.html`:

```html
<!doctype html>
<html lang="vi">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Pharma Equity Research</title>
  </head>
  <body>
    <div id="root"></div>
    <script type="module" src="/src/main.tsx"></script>
  </body>
</html>
```

`frontend/src/setupTests.ts`:

```ts
import "@testing-library/jest-dom";
```

`frontend/src/main.tsx`:

```tsx
import React from "react";
import ReactDOM from "react-dom/client";
import { BrowserRouter } from "react-router-dom";
import App from "./App";
import "./styles/tokens.css";
import "./styles/global.css";

ReactDOM.createRoot(document.getElementById("root")!).render(
  <React.StrictMode>
    <BrowserRouter>
      <App />
    </BrowserRouter>
  </React.StrictMode>
);
```

- [ ] **Step 3: Install and verify toolchain**

Run: `cd frontend && npm install`
Expected: installs without error. (App.tsx + styles created in later tasks; build deferred.)

- [ ] **Step 4: Commit**

```bash
git add frontend/package.json frontend/tsconfig.json frontend/tsconfig.node.json frontend/vite.config.ts frontend/vitest.config.ts frontend/index.html frontend/.env.development frontend/src/main.tsx frontend/src/setupTests.ts
git commit -m "chore(frontend): scaffold Vite + React + TS + Vitest"
```

---

### Task 7: API types + `runStatus` classification

**Files:**
- Create: `frontend/src/api/types.ts`, `frontend/src/api/runStatus.ts`
- Test: `frontend/src/api/runStatus.test.ts`

- [ ] **Step 1: Write the failing test**

```ts
// frontend/src/api/runStatus.test.ts
import { describe, it, expect } from "vitest";
import { classifyRunStatus } from "./runStatus";

describe("classifyRunStatus", () => {
  it("maps in-progress statuses", () => {
    for (const s of ["INIT", "INGESTING", "ANALYZING", "VALUATING", "SYNTHESIZING", "AUDITING"]) {
      expect(classifyRunStatus(s)).toBe("running");
    }
  });
  it("maps terminal success", () => {
    expect(classifyRunStatus("PUBLISHED")).toBe("success");
    expect(classifyRunStatus("PUBLISHED_DRAFT")).toBe("success");
  });
  it("maps terminal failure", () => {
    expect(classifyRunStatus("BLOCKED")).toBe("failed");
    expect(classifyRunStatus("FAILED")).toBe("failed");
  });
  it("treats unknown as running (defensive)", () => {
    expect(classifyRunStatus("WAT")).toBe("running");
  });
});
```

- [ ] **Step 2: Run test to verify it fails**

Run: `cd frontend && npx vitest run src/api/runStatus.test.ts`
Expected: FAIL — module not found.

- [ ] **Step 3: Write minimal implementation**

```ts
// frontend/src/api/types.ts
export interface ReportItem {
  ticker: string;
  company_name: string;
  exchange: string;
  segment: string;
  is_mvp: boolean;
  has_report: boolean;
  has_explanation: boolean;
  preview_pages: number[];
  report_size: number | null;
  updated_at: string | null;
}

export interface ReportsResponse {
  items: ReportItem[];
}

// Mirrors backend RunStatus public enum (backend/schemas.py + to_public_status)
export type RunStatus =
  | "INIT" | "INGESTING" | "ANALYZING" | "VALUATING"
  | "SYNTHESIZING" | "AUDITING" | "PUBLISHED" | "PUBLISHED_DRAFT"
  | "BLOCKED" | "FAILED";

export interface StartRunResponse { run_id: string; status: RunStatus; }
export interface RunStatusResponse {
  run_id: string;
  ticker: string;
  status: RunStatus;
  current_stage: string;
  updated_at: string;
  finished_at: string | null;
}
```

```ts
// frontend/src/api/runStatus.ts
import type { RunStatus } from "./types";

export type RunPhase = "running" | "success" | "failed";

const SUCCESS = new Set<string>(["PUBLISHED", "PUBLISHED_DRAFT"]);
const FAILED = new Set<string>(["BLOCKED", "FAILED"]);

export function classifyRunStatus(status: RunStatus | string): RunPhase {
  if (SUCCESS.has(status)) return "success";
  if (FAILED.has(status)) return "failed";
  return "running";
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `cd frontend && npx vitest run src/api/runStatus.test.ts`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add frontend/src/api/types.ts frontend/src/api/runStatus.ts frontend/src/api/runStatus.test.ts
git commit -m "feat(frontend): API types + run status classification"
```

---

### Task 8: `api/client.ts` typed fetch wrapper

**Files:**
- Create: `frontend/src/api/client.ts`
- Test: `frontend/src/api/client.test.ts`

- [ ] **Step 1: Write the failing test**

```ts
// frontend/src/api/client.test.ts
import { describe, it, expect, vi, beforeEach } from "vitest";
import { fetchReports, startRun, fetchRunStatus, fileUrl, previewUrl } from "./client";

beforeEach(() => { vi.restoreAllMocks(); });

describe("api client", () => {
  it("fetchReports hits /reports and returns items", async () => {
    const items = [{ ticker: "DHG" }];
    vi.stubGlobal("fetch", vi.fn(async () => new Response(JSON.stringify({ items }), { status: 200 })));
    const res = await fetchReports();
    expect((globalThis.fetch as any).mock.calls[0][0]).toBe("/reports");
    expect(res.items).toEqual(items);
  });

  it("startRun posts full_report run_type and templated objective", async () => {
    vi.stubGlobal("fetch", vi.fn(async () =>
      new Response(JSON.stringify({ run_id: "r1", status: "INIT" }), { status: 200 })));
    const res = await startRun("DHG");
    const [url, opts] = (globalThis.fetch as any).mock.calls[0];
    expect(url).toBe("/research/start");
    const body = JSON.parse(opts.body);
    expect(body.ticker).toBe("DHG");
    expect(body.run_type).toBe("full_report");
    expect(body.objective).toBe("Generate full equity research report for DHG");
    expect(res.run_id).toBe("r1");
  });

  it("fetchRunStatus hits status route", async () => {
    vi.stubGlobal("fetch", vi.fn(async () =>
      new Response(JSON.stringify({ run_id: "r1", status: "ANALYZING" }), { status: 200 })));
    await fetchRunStatus("r1");
    expect((globalThis.fetch as any).mock.calls[0][0]).toBe("/research/r1/status");
  });

  it("builds file and preview urls", () => {
    expect(fileUrl("DHG", "report")).toBe("/reports/DHG/file/report");
    expect(previewUrl("DHG", 3)).toBe("/reports/DHG/preview/3");
  });

  it("throws on non-ok", async () => {
    vi.stubGlobal("fetch", vi.fn(async () => new Response("nope", { status: 500 })));
    await expect(fetchReports()).rejects.toThrow();
  });
});
```

- [ ] **Step 2: Run test to verify it fails**

Run: `cd frontend && npx vitest run src/api/client.test.ts`
Expected: FAIL — module not found.

- [ ] **Step 3: Write minimal implementation**

```ts
// frontend/src/api/client.ts
import type { ReportsResponse, StartRunResponse, RunStatusResponse } from "./types";

const API_BASE = import.meta.env.VITE_API_BASE ?? "";

async function getJSON<T>(path: string): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`);
  if (!res.ok) throw new Error(`GET ${path} failed: ${res.status}`);
  return (await res.json()) as T;
}

export async function fetchReports(): Promise<ReportsResponse> {
  return getJSON<ReportsResponse>("/reports");
}

export async function startRun(ticker: string): Promise<StartRunResponse> {
  const res = await fetch(`${API_BASE}/research/start`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      ticker,
      run_type: "full_report",
      objective: `Generate full equity research report for ${ticker}`,
    }),
  });
  if (!res.ok) throw new Error(`startRun failed: ${res.status}`);
  return (await res.json()) as StartRunResponse;
}

export async function fetchRunStatus(runId: string): Promise<RunStatusResponse> {
  return getJSON<RunStatusResponse>(`/research/${runId}/status`);
}

export const fileUrl = (ticker: string, kind: "report" | "explanation") =>
  `${API_BASE}/reports/${ticker}/file/${kind}`;

export const previewUrl = (ticker: string, page: number) =>
  `${API_BASE}/reports/${ticker}/preview/${page}`;
```

- [ ] **Step 4: Run test to verify it passes**

Run: `cd frontend && npx vitest run src/api/client.test.ts`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add frontend/src/api/client.ts frontend/src/api/client.test.ts
git commit -m "feat(frontend): typed FastAPI client (reports, run, file/preview urls)"
```

---

### Task 9: `data/universe.ts` — 53 tickers

**Files:**
- Create: `frontend/src/data/universe.ts`
- Test: `frontend/src/data/universe.test.ts`

The list is generated from `config/dataset/universe/pharma_vn_universe.csv`. Note: the frontend also
gets live status from `/reports`; this static list is used for offline rendering and counts.

- [ ] **Step 1: Write the failing test**

```ts
// frontend/src/data/universe.test.ts
import { describe, it, expect } from "vitest";
import { UNIVERSE, segmentCounts } from "./universe";

describe("universe", () => {
  it("has 53 tickers", () => {
    expect(UNIVERSE.length).toBe(53);
  });
  it("segment breakdown matches the universe CSV", () => {
    const c = segmentCounts();
    expect(c.pharma).toBe(44);
    expect(c.healthcare_services).toBe(3);
    expect(c.medical_equipment).toBe(3);
    expect(c.medical_distribution).toBe(3);
  });
  it("DHG is MVP", () => {
    expect(UNIVERSE.find((t) => t.ticker === "DHG")?.is_mvp).toBe(true);
  });
});
```

- [ ] **Step 2: Run test to verify it fails**

Run: `cd frontend && npx vitest run src/data/universe.test.ts`
Expected: FAIL — module not found.

- [ ] **Step 3: Write minimal implementation**

Transcribe all 53 rows from the CSV. Shape:

```ts
// frontend/src/data/universe.ts
export interface UniverseTicker {
  ticker: string;
  company_name: string;
  exchange: string;
  segment: "pharma" | "healthcare_services" | "medical_equipment" | "medical_distribution";
  is_mvp: boolean;
}

export const UNIVERSE: UniverseTicker[] = [
  { ticker: "DHG", company_name: "Cong ty Co phan Duoc Hau Giang", exchange: "HOSE", segment: "pharma", is_mvp: true },
  { ticker: "IMP", company_name: "Cong ty Co phan Duoc pham Imexpharm", exchange: "HOSE", segment: "pharma", is_mvp: true },
  { ticker: "DMC", company_name: "Cong ty Co phan Xuat nhap khau Y te Domesco", exchange: "HOSE", segment: "pharma", is_mvp: true },
  { ticker: "TRA", company_name: "Cong ty Co phan Traphaco", exchange: "HOSE", segment: "pharma", is_mvp: true },
  { ticker: "DBD", company_name: "Cong ty Co phan Duoc - Trang thiet bi Y te Binh Dinh", exchange: "HOSE", segment: "pharma", is_mvp: true },
  { ticker: "OPC", company_name: "Cong ty Co phan Duoc pham OPC", exchange: "HOSE", segment: "pharma", is_mvp: false },
  { ticker: "PME", company_name: "Cong ty Co phan Pymepharco", exchange: "HOSE", segment: "pharma", is_mvp: false },
  { ticker: "MKP", company_name: "Cong ty Co phan Hoa - Duoc pham Mekophar", exchange: "HOSE", segment: "pharma", is_mvp: false },
  { ticker: "TNH", company_name: "Cong ty Co phan Benh vien Quoc te Thai Nguyen", exchange: "HOSE", segment: "healthcare_services", is_mvp: false },
  { ticker: "JVC", company_name: "Cong ty Co phan Thiet bi Y te Viet Nhat", exchange: "HOSE", segment: "medical_equipment", is_mvp: false },
  { ticker: "DVN", company_name: "Tong Cong ty Duoc Viet Nam - CTCP", exchange: "UPCOM", segment: "pharma", is_mvp: false },
  { ticker: "DHT", company_name: "Cong ty Co phan Duoc pham Ha Tay", exchange: "HNX", segment: "pharma", is_mvp: false },
  { ticker: "LDP", company_name: "Cong ty Co phan Duoc Lam Dong - Ladophar", exchange: "HNX", segment: "pharma", is_mvp: false },
  { ticker: "PPP", company_name: "Cong ty Co phan Duoc pham Phong Phu", exchange: "HNX", segment: "pharma", is_mvp: false },
  { ticker: "DP3", company_name: "Cong ty Co phan Duoc pham Trung uong 3", exchange: "UPCOM", segment: "pharma", is_mvp: false },
  { ticker: "DP1", company_name: "Cong ty Co phan Duoc pham Trung uong CPC1", exchange: "UPCOM", segment: "pharma", is_mvp: false },
  { ticker: "TW3", company_name: "Cong ty Co phan Duoc - Trang thiet bi Y te Da Nang", exchange: "UPCOM", segment: "pharma", is_mvp: false },
  { ticker: "MED", company_name: "Cong ty Co phan Duoc Trung uong Mediplantex", exchange: "UPCOM", segment: "pharma", is_mvp: false },
  { ticker: "PMC", company_name: "Cong ty Co phan Duoc pham Duoc lieu Pharmedic", exchange: "UPCOM", segment: "pharma", is_mvp: false },
  { ticker: "AMV", company_name: "Cong ty Co phan San xuat Kinh doanh Duoc va Trang thiet bi Y te Viet My", exchange: "HNX", segment: "medical_equipment", is_mvp: false },
  { ticker: "YTC", company_name: "Cong ty Co phan Xuat nhap khau Y te Thanh pho Ho Chi Minh", exchange: "UPCOM", segment: "medical_distribution", is_mvp: false },
  { ticker: "VHE", company_name: "Cong ty Co phan Duoc lieu Viet Nam", exchange: "UPCOM", segment: "pharma", is_mvp: false },
  { ticker: "VDP", company_name: "Cong ty Co phan Duoc pham Trung uong Vidipha", exchange: "UPCOM", segment: "pharma", is_mvp: false },
  { ticker: "DCL", company_name: "Cong ty Co phan Duoc pham Cuu Long", exchange: "HOSE", segment: "pharma", is_mvp: false },
  { ticker: "SPM", company_name: "Cong ty Co phan S.P.M", exchange: "HOSE", segment: "pharma", is_mvp: false },
  { ticker: "VMD", company_name: "Cong ty Co phan Y Duoc pham Vimedimex", exchange: "HNX", segment: "pharma", is_mvp: false },
  { ticker: "BVP", company_name: "Cong ty Co phan Duoc pham Binh Viet", exchange: "HNX", segment: "pharma", is_mvp: false },
  { ticker: "HBH", company_name: "Cong ty Co phan Chuoi Nha thuoc An Khang", exchange: "HOSE", segment: "medical_distribution", is_mvp: false },
  { ticker: "DNM", company_name: "Cong ty Co phan Dieu Duong Minh Hai", exchange: "UPCOM", segment: "pharma", is_mvp: false },
  { ticker: "DBT", company_name: "Cong ty Co phan Duoc pham Trung Viet", exchange: "UPCOM", segment: "pharma", is_mvp: false },
  { ticker: "DPP", company_name: "Cong ty Co phan Duoc pham Phuc Thanh", exchange: "UPCOM", segment: "pharma", is_mvp: false },
  { ticker: "DRP", company_name: "Cong ty Co phan Duoc Rarapharm", exchange: "UPCOM", segment: "pharma", is_mvp: false },
  { ticker: "T32", company_name: "Cong ty Co phan Y te Ha Tay", exchange: "UPCOM", segment: "healthcare_services", is_mvp: false },
  { ticker: "DTP", company_name: "Cong ty Co phan Duoc Tay Ninh", exchange: "UPCOM", segment: "pharma", is_mvp: false },
  { ticker: "VMC", company_name: "Cong ty Co phan Y Duoc Viet Nam", exchange: "UPCOM", segment: "pharma", is_mvp: false },
  { ticker: "NDT", company_name: "Cong ty Co phan Benh vien Da khoa tinh Ninh Binh", exchange: "UPCOM", segment: "healthcare_services", is_mvp: false },
  { ticker: "P29", company_name: "Cong ty Co phan Duoc pham Trung uong 29", exchange: "UPCOM", segment: "pharma", is_mvp: false },
  { ticker: "DDS", company_name: "Cong ty Co phan Diagnostics", exchange: "UPCOM", segment: "medical_equipment", is_mvp: false },
  { ticker: "BID", company_name: "Cong ty Co phan Duoc Binh Duong", exchange: "UPCOM", segment: "pharma", is_mvp: false },
  { ticker: "PDT", company_name: "Cong ty Co phan Duoc pham Dong Thap", exchange: "UPCOM", segment: "pharma", is_mvp: false },
  { ticker: "BCR", company_name: "Cong ty Co phan Bio-Pharmachemie", exchange: "UPCOM", segment: "pharma", is_mvp: false },
  { ticker: "VNP", company_name: "Cong ty Co phan Duoc Viet Nhon", exchange: "UPCOM", segment: "pharma", is_mvp: false },
  { ticker: "YT1", company_name: "Cong ty Co phan Duoc pham Y te 1", exchange: "UPCOM", segment: "pharma", is_mvp: false },
  { ticker: "CPC", company_name: "Cong ty Co phan Duoc pham CPC1 Ha Noi", exchange: "UPCOM", segment: "pharma", is_mvp: false },
  { ticker: "HDA", company_name: "Cong ty Co phan Duoc Ha Dong", exchange: "UPCOM", segment: "pharma", is_mvp: false },
  { ticker: "TMP", company_name: "Cong ty Co phan Duoc pham Tam Phuc", exchange: "UPCOM", segment: "pharma", is_mvp: false },
  { ticker: "DRG", company_name: "Cong ty Co phan Duoc Re Giang", exchange: "UPCOM", segment: "pharma", is_mvp: false },
  { ticker: "LNT", company_name: "Cong ty Co phan Duoc Lien", exchange: "UPCOM", segment: "pharma", is_mvp: false },
  { ticker: "HGP", company_name: "Cong ty Co phan Duoc pham Hung Gia", exchange: "UPCOM", segment: "pharma", is_mvp: false },
  { ticker: "PVD", company_name: "Cong ty Co phan Duoc pham Viet Duc", exchange: "UPCOM", segment: "pharma", is_mvp: false },
  { ticker: "DGW", company_name: "Cong ty Co phan The gioi So", exchange: "HOSE", segment: "medical_distribution", is_mvp: false },
  { ticker: "CON", company_name: "Cong ty Co phan Duoc pham Con Khi", exchange: "UPCOM", segment: "pharma", is_mvp: false },
  { ticker: "TNT", company_name: "Cong ty Co phan Duoc pham Tan Nhon Tay", exchange: "UPCOM", segment: "pharma", is_mvp: false },
];

export function segmentCounts(): Record<string, number> {
  return UNIVERSE.reduce<Record<string, number>>((acc, t) => {
    acc[t.segment] = (acc[t.segment] ?? 0) + 1;
    return acc;
  }, {});
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `cd frontend && npx vitest run src/data/universe.test.ts`
Expected: PASS (53 tickers; pharma 43 / healthcare_services 3 / medical_equipment 3 / medical_distribution 3).

- [ ] **Step 5: Commit**

```bash
git add frontend/src/data/universe.ts frontend/src/data/universe.test.ts
git commit -m "feat(frontend): static 53-ticker pharma universe"
```

---

## PHASE C — Reports page

### Task 10: `lib/reportFilter.ts` — pure filtering

**Files:**
- Create: `frontend/src/lib/reportFilter.ts`
- Test: `frontend/src/lib/reportFilter.test.ts`

- [ ] **Step 1: Write the failing test**

```ts
// frontend/src/lib/reportFilter.test.ts
import { describe, it, expect } from "vitest";
import { filterReports, type ReportFilterState } from "./reportFilter";
import type { ReportItem } from "../api/types";

const base: ReportItem = {
  ticker: "DHG", company_name: "Duoc Hau Giang", exchange: "HOSE",
  segment: "pharma", is_mvp: true, has_report: true, has_explanation: true,
  preview_pages: [1], report_size: 10, updated_at: "x",
};

const rows: ReportItem[] = [
  base,
  { ...base, ticker: "IMP", company_name: "Imexpharm", has_report: false, has_explanation: false, is_mvp: true },
  { ...base, ticker: "JVC", company_name: "Viet Nhat", segment: "medical_equipment", exchange: "HOSE", is_mvp: false, has_report: false },
];

const empty: ReportFilterState = { query: "", segment: "all", exchange: "all", status: "all", mvpOnly: false };

describe("filterReports", () => {
  it("returns all with empty filter", () => {
    expect(filterReports(rows, empty).length).toBe(3);
  });
  it("matches ticker and name case-insensitively", () => {
    expect(filterReports(rows, { ...empty, query: "imex" }).map((r) => r.ticker)).toEqual(["IMP"]);
    expect(filterReports(rows, { ...empty, query: "dhg" }).map((r) => r.ticker)).toEqual(["DHG"]);
  });
  it("filters by segment and exchange", () => {
    expect(filterReports(rows, { ...empty, segment: "medical_equipment" }).map((r) => r.ticker)).toEqual(["JVC"]);
  });
  it("filters by status has_report", () => {
    expect(filterReports(rows, { ...empty, status: "has_report" }).map((r) => r.ticker)).toEqual(["DHG"]);
    expect(filterReports(rows, { ...empty, status: "pending" }).map((r) => r.ticker)).toEqual(["IMP", "JVC"]);
  });
  it("filters mvp only", () => {
    expect(filterReports(rows, { ...empty, mvpOnly: true }).map((r) => r.ticker)).toEqual(["DHG", "IMP"]);
  });
});
```

- [ ] **Step 2: Run test to verify it fails**

Run: `cd frontend && npx vitest run src/lib/reportFilter.test.ts`
Expected: FAIL — module not found.

- [ ] **Step 3: Write minimal implementation**

```ts
// frontend/src/lib/reportFilter.ts
import type { ReportItem } from "../api/types";

export interface ReportFilterState {
  query: string;
  segment: string;   // "all" | segment
  exchange: string;  // "all" | exchange
  status: string;    // "all" | "has_report" | "pending"
  mvpOnly: boolean;
}

export function filterReports(rows: ReportItem[], f: ReportFilterState): ReportItem[] {
  const q = f.query.trim().toLowerCase();
  return rows.filter((r) => {
    if (q && !(`${r.ticker} ${r.company_name}`.toLowerCase().includes(q))) return false;
    if (f.segment !== "all" && r.segment !== f.segment) return false;
    if (f.exchange !== "all" && r.exchange !== f.exchange) return false;
    if (f.status === "has_report" && !r.has_report) return false;
    if (f.status === "pending" && r.has_report) return false;
    if (f.mvpOnly && !r.is_mvp) return false;
    return true;
  });
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `cd frontend && npx vitest run src/lib/reportFilter.test.ts`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add frontend/src/lib/reportFilter.ts frontend/src/lib/reportFilter.test.ts
git commit -m "feat(frontend): pure report filtering"
```

---

### Task 11: GenerateButton — polling with real RunStatus mapping

**Files:**
- Create: `frontend/src/components/reports/GenerateButton.tsx`
- Test: `frontend/src/components/reports/GenerateButton.test.tsx`

**REQUIRED SUB-SKILL:** frontend-design for the button/badge visuals. Logic + behavior below are fixed.

- [ ] **Step 1: Write the failing test**

```tsx
// frontend/src/components/reports/GenerateButton.test.tsx
import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { GenerateButton } from "./GenerateButton";
import * as client from "../../api/client";

beforeEach(() => vi.restoreAllMocks());

describe("GenerateButton", () => {
  it("starts a run then shows running, then success and calls onComplete", async () => {
    vi.spyOn(client, "startRun").mockResolvedValue({ run_id: "r1", status: "INIT" });
    const statuses = ["ANALYZING", "PUBLISHED"];
    let i = 0;
    vi.spyOn(client, "fetchRunStatus").mockImplementation(async () => ({
      run_id: "r1", ticker: "DHG", status: statuses[Math.min(i++, statuses.length - 1)] as any,
      current_stage: "", updated_at: "", finished_at: null,
    }));
    const onComplete = vi.fn();
    render(<GenerateButton ticker="DHG" pollMs={1} onComplete={onComplete} />);

    await userEvent.click(screen.getByRole("button", { name: /sinh báo cáo|generate/i }));
    expect(client.startRun).toHaveBeenCalledWith("DHG");
    await screen.findByText(/đang chạy|running/i);
    await screen.findByText(/xong|done|success/i);
    expect(onComplete).toHaveBeenCalled();
  });

  it("shows failure on BLOCKED and stops", async () => {
    vi.spyOn(client, "startRun").mockResolvedValue({ run_id: "r2", status: "INIT" });
    vi.spyOn(client, "fetchRunStatus").mockResolvedValue({
      run_id: "r2", ticker: "DHG", status: "BLOCKED",
      current_stage: "", updated_at: "", finished_at: null,
    });
    render(<GenerateButton ticker="DHG" pollMs={1} onComplete={vi.fn()} />);
    await userEvent.click(screen.getByRole("button", { name: /sinh báo cáo|generate/i }));
    await screen.findByText(/lỗi|thất bại|failed|blocked/i);
  });
});
```

- [ ] **Step 2: Run test to verify it fails**

Run: `cd frontend && npx vitest run src/components/reports/GenerateButton.test.tsx`
Expected: FAIL — module not found.

- [ ] **Step 3: Write minimal implementation**

```tsx
// frontend/src/components/reports/GenerateButton.tsx
import { useEffect, useRef, useState } from "react";
import { startRun, fetchRunStatus } from "../../api/client";
import { classifyRunStatus, type RunPhase } from "../../api/runStatus";

interface Props {
  ticker: string;
  onComplete: () => void;
  pollMs?: number;
}

type UiState = "idle" | "running" | "success" | "failed";

export function GenerateButton({ ticker, onComplete, pollMs = 4000 }: Props) {
  const [state, setState] = useState<UiState>("idle");
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => () => { if (timer.current) clearTimeout(timer.current); }, []);

  async function poll(runId: string) {
    const res = await fetchRunStatus(runId);
    const phase: RunPhase = classifyRunStatus(res.status);
    if (phase === "success") { setState("success"); onComplete(); return; }
    if (phase === "failed") { setState("failed"); return; }
    timer.current = setTimeout(() => void poll(runId), pollMs);
  }

  async function handleClick() {
    setState("running");
    try {
      const res = await startRun(ticker);
      void poll(res.run_id);
    } catch {
      setState("failed");
    }
  }

  if (state === "running") return <span role="status">Đang chạy…</span>;
  if (state === "success") return <span role="status">Xong</span>;
  if (state === "failed") return <span role="status">Thất bại</span>;
  return <button onClick={handleClick}>Sinh báo cáo</button>;
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `cd frontend && npx vitest run src/components/reports/GenerateButton.test.tsx`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add frontend/src/components/reports/GenerateButton.tsx frontend/src/components/reports/GenerateButton.test.tsx
git commit -m "feat(frontend): GenerateButton with RunStatus-mapped polling"
```

---

### Task 12: ReportRow + ReportFilters + PreviewPanel (presentational)

**Files:**
- Create: `frontend/src/components/reports/ReportRow.tsx`,
  `frontend/src/components/reports/ReportFilters.tsx`,
  `frontend/src/components/reports/PreviewPanel.tsx`
- Test: `frontend/src/components/reports/ReportRow.test.tsx`

**REQUIRED SUB-SKILL:** frontend-design for visuals. The test below pins the behavioral contract
(action enablement by status); styling is the frontend-design skill's job.

- [ ] **Step 1: Write the failing test**

```tsx
// frontend/src/components/reports/ReportRow.test.tsx
import { describe, it, expect, vi } from "vitest";
import { render, screen } from "@testing-library/react";
import { ReportRow } from "./ReportRow";
import type { ReportItem } from "../../api/types";

const item: ReportItem = {
  ticker: "DHG", company_name: "Duoc Hau Giang", exchange: "HOSE", segment: "pharma",
  is_mvp: true, has_report: true, has_explanation: false, preview_pages: [1, 2],
  report_size: 100, updated_at: "2026-06-14T00:00:00Z",
};

describe("ReportRow", () => {
  it("enables report download, disables explanation when missing", () => {
    render(<table><tbody>
      <ReportRow item={item} onPreview={vi.fn()} onGenerated={vi.fn()} />
    </tbody></table>);
    expect(screen.getByText("DHG")).toBeInTheDocument();
    const dl = screen.getByRole("link", { name: /tải report|download report/i });
    expect(dl).toHaveAttribute("href", "/reports/DHG/file/report");
    // explanation missing -> rendered disabled (no link role) or aria-disabled
    expect(screen.queryByRole("link", { name: /explanation/i })).toBeNull();
  });
});
```

- [ ] **Step 2: Run test to verify it fails**

Run: `cd frontend && npx vitest run src/components/reports/ReportRow.test.tsx`
Expected: FAIL — module not found.

- [ ] **Step 3: Write minimal implementation**

Use frontend-design for final styling. Minimal contract-satisfying implementation:

```tsx
// frontend/src/components/reports/ReportRow.tsx
import { fileUrl } from "../../api/client";
import type { ReportItem } from "../../api/types";
import { GenerateButton } from "./GenerateButton";

interface Props {
  item: ReportItem;
  onPreview: (ticker: string) => void;
  onGenerated: () => void;
}

export function ReportRow({ item, onPreview, onGenerated }: Props) {
  const statusLabel = item.has_report
    ? item.has_explanation ? "✓ Đầy đủ" : "◑ Chỉ report"
    : "⏳ Chưa sinh";
  return (
    <tr>
      <td>{item.ticker}</td>
      <td>{item.company_name}</td>
      <td>{item.exchange}</td>
      <td>{item.segment}</td>
      <td>{item.is_mvp ? "MVP" : ""}</td>
      <td>{statusLabel}</td>
      <td>
        {item.has_report && (
          <button onClick={() => onPreview(item.ticker)}>Xem trước</button>
        )}
        {item.has_report ? (
          <a href={fileUrl(item.ticker, "report")} target="_blank" rel="noreferrer">Tải report</a>
        ) : null}
        {item.has_explanation ? (
          <a href={fileUrl(item.ticker, "explanation")} target="_blank" rel="noreferrer">Tải explanation</a>
        ) : null}
        {!item.has_report && <GenerateButton ticker={item.ticker} onComplete={onGenerated} />}
      </td>
    </tr>
  );
}
```

```tsx
// frontend/src/components/reports/ReportFilters.tsx
import type { ReportFilterState } from "../../lib/reportFilter";

interface Props {
  value: ReportFilterState;
  onChange: (next: ReportFilterState) => void;
  segments: string[];
  exchanges: string[];
}

export function ReportFilters({ value, onChange, segments, exchanges }: Props) {
  const set = (patch: Partial<ReportFilterState>) => onChange({ ...value, ...patch });
  return (
    <div role="search">
      <input aria-label="search" placeholder="Tìm ticker / tên" value={value.query}
        onChange={(e) => set({ query: e.target.value })} />
      <select aria-label="segment" value={value.segment} onChange={(e) => set({ segment: e.target.value })}>
        <option value="all">Mọi segment</option>
        {segments.map((s) => <option key={s} value={s}>{s}</option>)}
      </select>
      <select aria-label="exchange" value={value.exchange} onChange={(e) => set({ exchange: e.target.value })}>
        <option value="all">Mọi sàn</option>
        {exchanges.map((x) => <option key={x} value={x}>{x}</option>)}
      </select>
      <select aria-label="status" value={value.status} onChange={(e) => set({ status: e.target.value })}>
        <option value="all">Mọi trạng thái</option>
        <option value="has_report">Đã có report</option>
        <option value="pending">Chưa sinh</option>
      </select>
      <label><input type="checkbox" checked={value.mvpOnly} onChange={(e) => set({ mvpOnly: e.target.checked })} /> MVP</label>
    </div>
  );
}
```

> NOTE: remove the stray `philosophy` token shown above — it is a deliberate typo guard; the real
> attribute is `onChange`. (See self-review note in Task 12.)

```tsx
// frontend/src/components/reports/PreviewPanel.tsx
import { previewUrl, fileUrl } from "../../api/client";
import type { ReportItem } from "../../api/types";

interface Props { item: ReportItem | null; onClose: () => void; }

export function PreviewPanel({ item, onClose }: Props) {
  if (!item) return null;
  return (
    <aside aria-label="preview">
      <header>
        <span>{item.ticker} — {item.company_name}</span>
        <button onClick={onClose}>Đóng</button>
      </header>
      {item.preview_pages.length > 0 ? (
        item.preview_pages.map((p) => (
          <img key={p} src={previewUrl(item.ticker, p)} alt={`${item.ticker} trang ${p}`} loading="lazy" />
        ))
      ) : (
        <iframe title="report-pdf" src={fileUrl(item.ticker, "report")} style={{ width: "100%", height: "80vh" }} />
      )}
    </aside>
  );
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `cd frontend && npx vitest run src/components/reports/ReportRow.test.tsx`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add frontend/src/components/reports/ReportRow.tsx frontend/src/components/reports/ReportFilters.tsx frontend/src/components/reports/PreviewPanel.tsx frontend/src/components/reports/ReportRow.test.tsx
git commit -m "feat(frontend): report row, filters, preview panel"
```

---

### Task 13: ReportsPage composition

**Files:**
- Create: `frontend/src/pages/ReportsPage.tsx`
- Test: `frontend/src/pages/ReportsPage.test.tsx`

**REQUIRED SUB-SKILL:** frontend-design for the page layout/header/summary visuals.

- [ ] **Step 1: Write the failing test**

```tsx
// frontend/src/pages/ReportsPage.test.tsx
import { describe, it, expect, vi, beforeEach } from "vitest";
import { render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { ReportsPage } from "./ReportsPage";
import * as client from "../api/client";

beforeEach(() => vi.restoreAllMocks());

describe("ReportsPage", () => {
  it("loads /reports and renders rows, then filters", async () => {
    vi.spyOn(client, "fetchReports").mockResolvedValue({
      items: [
        { ticker: "DHG", company_name: "Duoc Hau Giang", exchange: "HOSE", segment: "pharma", is_mvp: true, has_report: true, has_explanation: true, preview_pages: [1], report_size: 1, updated_at: "x" },
        { ticker: "IMP", company_name: "Imexpharm", exchange: "HOSE", segment: "pharma", is_mvp: true, has_report: false, has_explanation: false, preview_pages: [], report_size: null, updated_at: null },
      ],
    });
    render(<ReportsPage />);
    await screen.findByText("DHG");
    expect(screen.getByText("IMP")).toBeInTheDocument();
    await userEvent.type(screen.getByLabelText("search"), "imex");
    expect(screen.queryByText("DHG")).toBeNull();
    expect(screen.getByText("IMP")).toBeInTheDocument();
  });
});
```

- [ ] **Step 2: Run test to verify it fails**

Run: `cd frontend && npx vitest run src/pages/ReportsPage.test.tsx`
Expected: FAIL — module not found.

- [ ] **Step 3: Write minimal implementation**

```tsx
// frontend/src/pages/ReportsPage.tsx
import { useEffect, useMemo, useState } from "react";
import { fetchReports } from "../api/client";
import type { ReportItem } from "../api/types";
import { filterReports, type ReportFilterState } from "../lib/reportFilter";
import { ReportFilters } from "../components/reports/ReportFilters";
import { ReportRow } from "../components/reports/ReportRow";
import { PreviewPanel } from "../components/reports/PreviewPanel";

const EMPTY: ReportFilterState = { query: "", segment: "all", exchange: "all", status: "all", mvpOnly: false };

export function ReportsPage() {
  const [items, setItems] = useState<ReportItem[]>([]);
  const [filter, setFilter] = useState<ReportFilterState>(EMPTY);
  const [previewTicker, setPreviewTicker] = useState<string | null>(null);

  const load = () => { void fetchReports().then((r) => setItems(r.items)); };
  useEffect(load, []);

  const filtered = useMemo(() => filterReports(items, filter), [items, filter]);
  const segments = useMemo(() => [...new Set(items.map((i) => i.segment))], [items]);
  const exchanges = useMemo(() => [...new Set(items.map((i) => i.exchange))], [items]);
  const previewItem = items.find((i) => i.ticker === previewTicker) ?? null;
  const withReport = items.filter((i) => i.has_report).length;

  return (
    <section>
      <header>
        <h1>Báo cáo dược phẩm</h1>
        <p>{items.length} ticker · {withReport} đã có báo cáo · {items.length - withReport} chưa sinh</p>
      </header>
      <ReportFilters value={filter} onChange={setFilter} segments={segments} exchanges={exchanges} />
      <table>
        <thead><tr><th>Ticker</th><th>Tên</th><th>Sàn</th><th>Segment</th><th>MVP</th><th>Trạng thái</th><th>Hành động</th></tr></thead>
        <tbody>
          {filtered.map((it) => (
            <ReportRow key={it.ticker} item={it} onPreview={setPreviewTicker} onGenerated={load} />
          ))}
        </tbody>
      </table>
      <PreviewPanel item={previewItem} onClose={() => setPreviewTicker(null)} />
    </section>
  );
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `cd frontend && npx vitest run src/pages/ReportsPage.test.tsx`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add frontend/src/pages/ReportsPage.tsx frontend/src/pages/ReportsPage.test.tsx
git commit -m "feat(frontend): ReportsPage compose (load, filter, preview, generate)"
```

---

## PHASE D — Eval framework + dashboard

### Task 14: `lib/evalStatus.ts` — pure threshold logic

**Files:**
- Create: `frontend/src/lib/evalStatus.ts`
- Test: `frontend/src/lib/evalStatus.test.ts`

- [ ] **Step 1: Write the failing test**

```ts
// frontend/src/lib/evalStatus.test.ts
import { describe, it, expect } from "vitest";
import { evalMetricStatus, type MetricDef } from "./evalStatus";

const gte: MetricDef = {
  id: "coverage", label: "Coverage", unit: "%", comparator: "gte",
  thresholds: { P0: 0.95, P1: 0.95, P2: 0.95 },
};
const lte: MetricDef = {
  id: "dupes", label: "Duplicates", unit: "%", comparator: "lte",
  thresholds: { P0: 0, P1: 0, P2: 0 },
};
const measuredAtP0: MetricDef = {
  id: "hit", label: "Hit-rate@5", unit: "", comparator: "gte",
  thresholds: { P0: null, P1: 0.9, P2: 0.95 },
};

describe("evalMetricStatus", () => {
  it("gte pass/fail", () => {
    expect(evalMetricStatus(gte, 0.96, "P0")).toBe("pass");
    expect(evalMetricStatus(gte, 0.90, "P0")).toBe("fail");
  });
  it("lte pass/fail", () => {
    expect(evalMetricStatus(lte, 0, "P0")).toBe("pass");
    expect(evalMetricStatus(lte, 0.01, "P0")).toBe("fail");
  });
  it("null threshold at maturity is measured_only", () => {
    expect(evalMetricStatus(measuredAtP0, 0.5, "P0")).toBe("measured_only");
    expect(evalMetricStatus(measuredAtP0, 0.95, "P1")).toBe("pass");
    expect(evalMetricStatus(measuredAtP0, 0.5, "P1")).toBe("fail");
  });
  it("missing value is measured_only", () => {
    expect(evalMetricStatus(gte, null, "P0")).toBe("measured_only");
  });
});
```

- [ ] **Step 2: Run test to verify it fails**

Run: `cd frontend && npx vitest run src/lib/evalStatus.test.ts`
Expected: FAIL — module not found.

- [ ] **Step 3: Write minimal implementation**

```ts
// frontend/src/lib/evalStatus.ts
export type Maturity = "P0" | "P1" | "P2";
export type Comparator = "gte" | "lte";
export type MetricStatus = "pass" | "fail" | "measured_only";

export interface MetricDef {
  id: string;
  label: string;
  unit: string;
  comparator: Comparator;
  thresholds: Record<Maturity, number | null>;
}

export function evalMetricStatus(
  def: MetricDef,
  value: number | null | undefined,
  maturity: Maturity
): MetricStatus {
  const threshold = def.thresholds[maturity];
  if (threshold === null || threshold === undefined) return "measured_only";
  if (value === null || value === undefined || Number.isNaN(value)) return "measured_only";
  if (def.comparator === "gte") return value >= threshold ? "pass" : "fail";
  return value <= threshold ? "pass" : "fail";
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `cd frontend && npx vitest run src/lib/evalStatus.test.ts`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add frontend/src/lib/evalStatus.ts frontend/src/lib/evalStatus.test.ts
git commit -m "feat(frontend): pure eval metric threshold status"
```

---

### Task 15: `data/evalFramework.ts` — declarative 8 layers

**Files:**
- Create: `frontend/src/data/evalFramework.ts`
- Test: `frontend/src/data/evalFramework.test.ts`

Source of all thresholds: `eval/01..08_*.md`. Encode each metric with `comparator` and per-maturity
`thresholds` (use `null` where the plan says "Measured only"). Also encode the fail-closed pipeline
order, the CI gate matrix, and the maturity acceptance table for Layer 8 (display-only).

- [ ] **Step 1: Write the failing test**

```ts
// frontend/src/data/evalFramework.test.ts
import { describe, it, expect } from "vitest";
import { EVAL_LAYERS, PIPELINE_ORDER, CI_GATE_MATRIX, MATURITY_TABLE } from "./evalFramework";

describe("evalFramework", () => {
  it("has 8 layers in fail-closed order", () => {
    expect(EVAL_LAYERS.length).toBe(8);
    expect(EVAL_LAYERS[0].id).toBe("data_reliability");
    expect(EVAL_LAYERS[5].id).toBe("report_fpts");
  });
  it("each layer references its artifact and has metrics or rows", () => {
    for (const l of EVAL_LAYERS) {
      expect(l.title.length).toBeGreaterThan(0);
      expect(l.artifact).toBeDefined();
    }
  });
  it("RAG hit-rate is measured_only at P0", () => {
    const rag = EVAL_LAYERS.find((l) => l.id === "rag_evidence")!;
    const hit = rag.metrics!.find((m) => m.id === "hit_rate_at_5")!;
    expect(hit.thresholds.P0).toBeNull();
    expect(hit.thresholds.P1).toBe(0.9);
  });
  it("pipeline order starts at data and ends at client-final authorization", () => {
    expect(PIPELINE_ORDER[0]).toMatch(/Data reliability/i);
    expect(PIPELINE_ORDER[PIPELINE_ORDER.length - 1]).toMatch(/Client-final/i);
  });
  it("CI matrix and maturity table are non-empty", () => {
    expect(CI_GATE_MATRIX.length).toBeGreaterThan(0);
    expect(MATURITY_TABLE.length).toBeGreaterThan(0);
  });
});
```

- [ ] **Step 2: Run test to verify it fails**

Run: `cd frontend && npx vitest run src/data/evalFramework.test.ts`
Expected: FAIL — module not found.

- [ ] **Step 3: Write minimal implementation**

```ts
// frontend/src/data/evalFramework.ts
import type { MetricDef } from "../lib/evalStatus";

export interface EvalLayer {
  id: string;
  title: string;
  subtitle: string;
  artifact: string;            // e.g. "data_quality.json"
  metrics?: MetricDef[];       // metric-driven layers
  invariants?: string[];       // Layer 3 critical invariants (display)
  rubricDimensions?: string[]; // Layer 5 judge rubric (display)
  blockingConditions?: string[]; // Layer 6 (display)
}

const t = (P0: number | null, P1: number | null, P2: number | null) => ({ P0, P1, P2 });

export const EVAL_LAYERS: EvalLayer[] = [
  {
    id: "data_reliability",
    title: "1 · Data reliability",
    subtitle: "Fact ingestion, provenance, reconciliation, freshness",
    artifact: "data_quality.json",
    metrics: [
      { id: "core_metric_coverage", label: "Core metric coverage", unit: "%", comparator: "gte", thresholds: t(0.95, 0.95, 0.95) },
      { id: "period_completeness", label: "Period completeness", unit: "%", comparator: "gte", thresholds: t(1, 1, 1) },
      { id: "provenance_coverage", label: "Source provenance coverage", unit: "%", comparator: "gte", thresholds: t(1, 1, 1) },
      { id: "official_reconciliation_rate", label: "Official reconciliation rate", unit: "%", comparator: "gte", thresholds: t(0.95, 0.95, 0.95) },
      { id: "ocr_unresolved_rate", label: "OCR unresolved rate", unit: "%", comparator: "lte", thresholds: t(0, 0, 0) },
      { id: "duplicate_fact_rate", label: "Duplicate fact rate", unit: "%", comparator: "lte", thresholds: t(0, 0, 0) },
    ],
  },
  {
    id: "rag_evidence",
    title: "2 · RAG & evidence",
    subtitle: "Retrieval, citation evidence, Ragas metrics",
    artifact: "retrieval_eval.json",
    metrics: [
      { id: "hit_rate_at_5", label: "Hit-rate@5", unit: "%", comparator: "gte", thresholds: t(null, 0.9, 0.95) },
      { id: "mrr_at_5", label: "MRR@5", unit: "", comparator: "gte", thresholds: t(null, 0.8, 0.8) },
      { id: "context_precision", label: "Context precision", unit: "", comparator: "gte", thresholds: t(null, 0.85, 0.85) },
      { id: "context_recall", label: "Context recall", unit: "", comparator: "gte", thresholds: t(null, 0.85, 0.85) },
      { id: "faithfulness", label: "Faithfulness", unit: "", comparator: "gte", thresholds: t(null, 0.85, 0.9) },
      { id: "response_relevancy", label: "Response relevancy", unit: "", comparator: "gte", thresholds: t(null, 0.85, 0.85) },
    ],
  },
  {
    id: "financial",
    title: "3 · Financial calculation",
    subtitle: "Deterministic invariants — LLM must not compute these",
    artifact: "financial_eval.json",
    metrics: [
      { id: "critical_failures", label: "Critical invariant failures", unit: "", comparator: "lte", thresholds: t(0, 0, 0) },
      { id: "golden_drift_out_of_tolerance", label: "Golden valuation drift out of tolerance", unit: "", comparator: "lte", thresholds: t(0, 0, 0) },
    ],
    invariants: [
      "Net debt = interest_bearing_debt − cash − short_term_investments",
      "EPS = net_income × 1000 / diluted_shares_mn",
      "BS balance: assets = equity + debt + other_liabilities",
      "FCFF = EBIT(1−tax) + D&A − CAPEX − ΔNWC",
      "FCFE = NI + D&A − CAPEX − ΔNWC + net_borrowing",
      "EV-to-equity bridge",
      "Target price = equity_value / diluted_shares",
      "Gordon growth: discount_rate > terminal_growth",
      "Sensitivity matrix varies (≥2 distinct values)",
      "Sensitivity base cell matches target price",
      "Recommendation matches upside policy",
    ],
  },
  {
    id: "citation",
    title: "4 · Citation & provenance",
    subtitle: "Claim-level coverage, source tier, official source requirement",
    artifact: "citation_eval.json",
    metrics: [
      { id: "quant_citation_coverage", label: "Quantitative citation coverage", unit: "%", comparator: "gte", thresholds: t(1, 1, 1) },
      { id: "citation_key_resolution", label: "Citation key resolution", unit: "%", comparator: "gte", thresholds: t(1, 1, 1) },
      { id: "source_id_validity", label: "Source ID validity", unit: "%", comparator: "gte", thresholds: t(1, 1, 1) },
      { id: "official_source_coverage", label: "Official source coverage (material quant.)", unit: "%", comparator: "gte", thresholds: t(1, 1, 1) },
      { id: "numeric_mismatch_rate", label: "Numeric mismatch rate (> tol.)", unit: "%", comparator: "lte", thresholds: t(0, 0, 0) },
      { id: "tier3_only_material_claims", label: "Tier-3-only material claims", unit: "", comparator: "lte", thresholds: t(0, 0, 0) },
      { id: "generic_citations", label: "Generic citation labels", unit: "", comparator: "lte", thresholds: t(0, 0, 0) },
      { id: "catalyst_without_evidence", label: "Catalyst events without evidence span", unit: "", comparator: "lte", thresholds: t(0, 0, 0) },
    ],
  },
  {
    id: "agent",
    title: "5 · Agent workflow & LLM judge",
    subtitle: "Tool permission, role adherence, groundedness, judge rubric",
    artifact: "agent_eval.json",
    metrics: [
      { id: "tool_permission_compliance", label: "Tool permission compliance", unit: "%", comparator: "gte", thresholds: t(1, 1, 1) },
      { id: "schema_validity", label: "Output schema validity", unit: "%", comparator: "gte", thresholds: t(1, 1, 1) },
      { id: "no_unauthorized_calc", label: "No unauthorized financial calculation", unit: "%", comparator: "gte", thresholds: t(1, 1, 1) },
      { id: "role_adherence", label: "Role adherence", unit: "", comparator: "gte", thresholds: t(null, 0.85, 0.9) },
      { id: "groundedness", label: "Groundedness (final narrative)", unit: "", comparator: "gte", thresholds: t(null, 0.85, 0.9) },
      { id: "task_completion", label: "Task completion", unit: "", comparator: "gte", thresholds: t(null, 0.85, 0.85) },
      { id: "plan_adherence", label: "Plan adherence", unit: "", comparator: "gte", thresholds: t(null, 0.85, 0.85) },
      { id: "critic_issue_recall", label: "Critic issue recall (seeded)", unit: "%", comparator: "gte", thresholds: t(null, 0.9, 0.9) },
    ],
    rubricDimensions: [
      "Evidence discipline", "Financial restraint", "Company specificity",
      "Materiality", "Risk balance", "Citation integrity", "Professional tone",
    ],
  },
  {
    id: "report_fpts",
    title: "6 · Report FPTS quality",
    subtitle: "FPTS grade, export gating, publication readiness",
    artifact: "report_eval.json",
    metrics: [
      { id: "fpts_score", label: "FPTS score", unit: "", comparator: "gte", thresholds: t(85, 85, 90) },
    ],
    blockingConditions: [
      "FPTS score < 85", "Any failed deterministic finance gate",
      "Recommendation visible before approval", "Target price from blocked valuation",
      "Report/valuation snapshot mismatch", "Missing evidence packet or formula trace",
      "PDF rendered from candidate model as final", "Missing final approval for client render",
      "publishable_final_report_model not locked", "FPTS warning treated as final pass",
      "Post-render client-final audit failed",
    ],
  },
  {
    id: "observability",
    title: "7 · Observability, cost & latency",
    subtitle: "Duration, tokens, cost, retries, fallback, render failures",
    artifact: "observability_eval.json",
    metrics: [
      { id: "llm_retry_rate", label: "LLM retry rate", unit: "%", comparator: "lte", thresholds: t(0.05, 0.05, 0.05) },
      { id: "retrieval_fallback_rate", label: "Retrieval fallback rate", unit: "%", comparator: "lte", thresholds: t(0.2, 0.2, 0.2) },
      { id: "ocr_failure_rate", label: "OCR failure rate (material)", unit: "%", comparator: "lte", thresholds: t(0.05, 0.05, 0.05) },
      { id: "artifact_upload_failures", label: "Artifact upload failures (final)", unit: "", comparator: "lte", thresholds: t(0, 0, 0) },
      { id: "pdf_render_failures", label: "PDF render failures (final)", unit: "", comparator: "lte", thresholds: t(0, 0, 0) },
    ],
  },
  {
    id: "rollout_ci",
    title: "8 · Rollout & CI",
    subtitle: "CI gate matrix and acceptance thresholds by maturity",
    artifact: "—",
  },
];

export const PIPELINE_ORDER: string[] = [
  "Data reliability",
  "Fact reconciliation",
  "Retrieval & source provenance",
  "Financial calculation invariants",
  "Agent & narrative",
  "Report FPTS grade",
  "Package validation & auto-exported draft",
  "Human final approval",
  "Client-final render authorization",
];

export interface CiGate { job: string; scope: string; blockMerge: string; }
export const CI_GATE_MATRIX: CiGate[] = [
  { job: "unit-core", scope: "tests/unit/ core deterministic", blockMerge: "Yes" },
  { job: "evaluation-gates", scope: "evaluation/citations/reconciliation + package/publication", blockMerge: "Yes" },
  { job: "finance-regression", scope: "DCF, ratios, debt, dividend, sensitivity, governance invariants", blockMerge: "Yes" },
  { job: "report-render-smoke", scope: "HTML/PDF smoke, post-render audit, authorization-required render", blockMerge: "Yes (if renderer required)" },
  { job: "rag-golden", scope: "Golden retrieval set", blockMerge: "Warn P1 → block P2" },
  { job: "llm-judge-offline", scope: "Calibrated report/agent dataset", blockMerge: "Warn → block after calibration" },
  { job: "integration-db", scope: "Supabase/PostgreSQL live tests", blockMerge: "Scheduled/protected" },
];

export interface MaturityRow { layer: string; P0: string; P1: string; P2: string; }
export const MATURITY_TABLE: MaturityRow[] = [
  { layer: "Data critical failures", P0: "0", P1: "0", P2: "0" },
  { layer: "Finance critical failures", P0: "0", P1: "0", P2: "0" },
  { layer: "Citation coverage (final)", P0: "100%", P1: "100%", P2: "100%" },
  { layer: "FPTS score", P0: "≥ 85", P1: "≥ 85", P2: "≥ 90 (published)" },
  { layer: "RAG hit-rate@5", P0: "Measured", P1: "≥ 90%", P2: "≥ 95%" },
  { layer: "Ragas faithfulness", P0: "Measured", P1: "≥ 0.85", P2: "≥ 0.90" },
  { layer: "Agent role adherence", P0: "Measured", P1: "≥ 0.85", P2: "≥ 0.90" },
  { layer: "Cost per report", P0: "Baseline", P1: "≤ +15%", P2: "Budgeted" },
];
```

- [ ] **Step 4: Run test to verify it passes**

Run: `cd frontend && npx vitest run src/data/evalFramework.test.ts`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add frontend/src/data/evalFramework.ts frontend/src/data/evalFramework.test.ts
git commit -m "feat(frontend): declarative 8-layer eval framework definition"
```

---

### Task 16: Mock artifacts (8 JSON files)

**Files:**
- Create: `frontend/src/mock/{data_quality,retrieval_eval,financial_eval,citation_eval,agent_eval,report_eval,publication_readiness,observability_eval}.json`
- Create: `frontend/src/mock/index.ts` (typed loader keyed by layer id)
- Test: `frontend/src/mock/index.test.ts`

Each JSON matches the artifact shape in the spec (§7.2). Use realistic passing-ish DHG values so the
dashboard renders meaningfully. The loader maps each metric `id` (from `evalFramework.ts`) to a value.

- [ ] **Step 1: Write the failing test**

```ts
// frontend/src/mock/index.test.ts
import { describe, it, expect } from "vitest";
import { mockValuesForLayer } from "./index";

describe("mock values", () => {
  it("returns a numeric map for data_reliability metric ids", () => {
    const v = mockValuesForLayer("data_reliability");
    expect(typeof v.core_metric_coverage).toBe("number");
    expect(typeof v.duplicate_fact_rate).toBe("number");
  });
  it("returns fpts_score for report_fpts", () => {
    expect(typeof mockValuesForLayer("report_fpts").fpts_score).toBe("number");
  });
  it("unknown layer yields empty map", () => {
    expect(mockValuesForLayer("nope")).toEqual({});
  });
});
```

- [ ] **Step 2: Run test to verify it fails**

Run: `cd frontend && npx vitest run src/mock/index.test.ts`
Expected: FAIL — module not found.

- [ ] **Step 3: Write minimal implementation**

Create the 8 JSON files (representative DHG values). Example `data_quality.json`:

```json
{
  "ticker": "DHG", "run_id": "mock-001",
  "core_metric_coverage": 0.97, "period_completeness": 1.0,
  "provenance_coverage": 1.0, "official_reconciliation_rate": 0.96,
  "ocr_unresolved_rate": 0.0, "duplicate_fact_rate": 0.0,
  "freshness_days": 12, "blocking_issues": []
}
```

`retrieval_eval.json`:

```json
{
  "ticker": "DHG", "run_id": "mock-001",
  "retrieval_backend": "hybrid", "query_set_version": "rag_golden_v1",
  "ragas_scores": { "context_precision": 0.83, "context_recall": 0.81, "faithfulness": 0.88, "response_relevancy": 0.86 },
  "golden_scores": { "hit_rate_at_5": 0.92, "mrr_at_5": 0.79 },
  "blocking_failures": []
}
```

`financial_eval.json`:

```json
{
  "ticker": "DHG", "run_id": "mock-001",
  "invariants": [
    { "id": "net_debt", "severity": "critical", "passed": true, "detail": "" },
    { "id": "fcff", "severity": "critical", "passed": true, "detail": "" },
    { "id": "fcfe", "severity": "critical", "passed": true, "detail": "" }
  ],
  "critical_failures": 0, "golden_drift_out_of_tolerance": 0,
  "missing_traces": [], "decision": "pass"
}
```

`citation_eval.json`:

```json
{
  "run_id": "mock-001", "ticker": "DHG",
  "claim_count": 84, "quantitative_claim_count": 41,
  "quant_citation_coverage": 1.0, "citation_key_resolution": 1.0,
  "source_id_validity": 1.0, "official_source_coverage": 1.0,
  "numeric_mismatch_rate": 0.0, "tier3_only_material_claims": 0,
  "generic_citations": 0, "catalyst_without_evidence": 0,
  "source_tier_counts": { "tier1": 30, "tier2": 9, "tier3": 2 },
  "export_blocked": false
}
```

`agent_eval.json`:

```json
{
  "ticker": "DHG", "run_id": "mock-001",
  "tool_permission_compliance": 1.0, "schema_validity": 1.0,
  "no_unauthorized_calc": 1.0, "role_adherence": 0.91, "groundedness": 0.9,
  "task_completion": 0.88, "plan_adherence": 0.87, "critic_issue_recall": 0.93,
  "rubric_scores": { "evidence_discipline": 0.9, "financial_restraint": 0.95, "company_specificity": 0.85, "materiality": 0.88, "risk_balance": 0.84, "citation_integrity": 0.92, "professional_tone": 0.9 },
  "blocking_failures": []
}
```

`report_eval.json`:

```json
{
  "rubric": "fpts_grade_v1", "fpts_score": 87, "score": 87,
  "decision": "allow_export", "failed_gates": [],
  "section_scores": { "thesis": 88, "valuation": 86, "risks": 85, "presentation": 89 },
  "report_artifacts": { "html": "output/DHG_report.html", "pdf": "output/DHG_report.pdf", "manifest": "output/DHG_manifest.json" },
  "publication_readiness": { "passed": true, "blocking_reasons": [] }
}
```

`publication_readiness.json`:

```json
{
  "passed": true, "run_approval": true, "final_approval": true,
  "locked_publishable_model": true, "package_gate": true,
  "fpts_allow_export": true, "snapshot_match": true, "blocking_reasons": []
}
```

`observability_eval.json`:

```json
{
  "run_id": "mock-001", "trace_url": "https://langfuse.local/trace/mock-001",
  "duration_seconds": 2140, "stage_durations": { "ingest": 320, "analyze": 540, "valuate": 410, "synthesize": 520, "audit": 350 },
  "llm": { "calls": 38, "tokens_input": 184000, "tokens_output": 42000, "estimated_cost_usd": 1.92, "retry_rate": 0.03 },
  "retrieval": { "queries": 64, "p95_latency_ms": 410, "fallback_rate": 0.08 },
  "ocr_failure_rate": 0.0, "artifact_upload_failures": 0, "pdf_render_failures": 0,
  "blocking_gate_categories": [],
  "publication": { "readiness_passed": true, "authorization_blockers": [], "render_mode": "client_final" }
}
```

`frontend/src/mock/index.ts`:

```ts
import dataQuality from "./data_quality.json";
import retrieval from "./retrieval_eval.json";
import financial from "./financial_eval.json";
import citation from "./citation_eval.json";
import agent from "./agent_eval.json";
import report from "./report_eval.json";
import publication from "./publication_readiness.json";
import observability from "./observability_eval.json";

export const MOCK_ARTIFACTS = {
  data_quality: dataQuality,
  retrieval_eval: retrieval,
  financial_eval: financial,
  citation_eval: citation,
  agent_eval: agent,
  report_eval: report,
  publication_readiness: publication,
  observability_eval: observability,
};

// Flatten each artifact to a metric-id -> number map matching evalFramework metric ids.
const LAYER_VALUE_MAP: Record<string, Record<string, number>> = {
  data_reliability: {
    core_metric_coverage: dataQuality.core_metric_coverage,
    period_completeness: dataQuality.period_completeness,
    provenance_coverage: dataQuality.provenance_coverage,
    official_reconciliation_rate: dataQuality.official_reconciliation_rate,
    ocr_unresolved_rate: dataQuality.ocr_unresolved_rate,
    duplicate_fact_rate: dataQuality.duplicate_fact_rate,
  },
  rag_evidence: {
    hit_rate_at_5: retrieval.golden_scores.hit_rate_at_5,
    mrr_at_5: retrieval.golden_scores.mrr_at_5,
    context_precision: retrieval.ragas_scores.context_precision,
    context_recall: retrieval.ragas_scores.context_recall,
    faithfulness: retrieval.ragas_scores.faithfulness,
    response_relevancy: retrieval.ragas_scores.response_relevancy,
  },
  financial: {
    critical_failures: financial.critical_failures,
    golden_drift_out_of_tolerance: financial.golden_drift_out_of_tolerance,
  },
  citation: {
    quant_citation_coverage: citation.quant_citation_coverage,
    citation_key_resolution: citation.citation_key_resolution,
    source_id_validity: citation.source_id_validity,
    official_source_coverage: citation.official_source_coverage,
    numeric_mismatch_rate: citation.numeric_mismatch_rate,
    tier3_only_material_claims: citation.tier3_only_material_claims,
    generic_citations: citation.generic_citations,
    catalyst_without_evidence: citation.catalyst_without_evidence,
  },
  agent: {
    tool_permission_compliance: agent.tool_permission_compliance,
    schema_validity: agent.schema_validity,
    no_unauthorized_calc: agent.no_unauthorized_calc,
    role_adherence: agent.role_adherence,
    groundedness: agent.groundedness,
    task_completion: agent.task_completion,
    plan_adherence: agent.plan_adherence,
    critic_issue_recall: agent.critic_issue_recall,
  },
  report_fpts: { fpts_score: report.fpts_score },
  observability: {
    llm_retry_rate: observability.llm.retry_rate,
    retrieval_fallback_rate: observability.retrieval.fallback_rate,
    ocr_failure_rate: observability.ocr_failure_rate,
    artifact_upload_failures: observability.artifact_upload_failures,
    pdf_render_failures: observability.pdf_render_failures,
  },
};

export function mockValuesForLayer(layerId: string): Record<string, number> {
  return LAYER_VALUE_MAP[layerId] ?? {};
}
```

Note: `tsconfig.json` already sets `resolveJsonModule: true`.

- [ ] **Step 4: Run test to verify it passes**

Run: `cd frontend && npx vitest run src/mock/index.test.ts`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add frontend/src/mock
git commit -m "feat(frontend): mock eval artifacts matching real schemas + layer value loader"
```

---

### Task 17: StatusPill + MetricRow + LayerCard (presentational)

**Files:**
- Create: `frontend/src/components/eval/{StatusPill,MetricRow,LayerCard}.tsx`
- Test: `frontend/src/components/eval/MetricRow.test.tsx`

**REQUIRED SUB-SKILL:** frontend-design for visuals. Test pins the status/threshold contract.

- [ ] **Step 1: Write the failing test**

```tsx
// frontend/src/components/eval/MetricRow.test.tsx
import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { MetricRow } from "./MetricRow";
import type { MetricDef } from "../../lib/evalStatus";

const def: MetricDef = {
  id: "cov", label: "Coverage", unit: "%", comparator: "gte",
  thresholds: { P0: 0.95, P1: 0.95, P2: 0.95 },
};

describe("MetricRow", () => {
  it("shows pass pill when value meets threshold at maturity", () => {
    render(<table><tbody><MetricRow def={def} value={0.97} maturity="P0" /></tbody></table>);
    expect(screen.getByText("Coverage")).toBeInTheDocument();
    expect(screen.getByText(/pass/i)).toBeInTheDocument();
  });
  it("shows fail pill when below threshold", () => {
    render(<table><tbody><MetricRow def={def} value={0.5} maturity="P0" /></tbody></table>);
    expect(screen.getByText(/fail/i)).toBeInTheDocument();
  });
  it("shows measured-only when threshold null at maturity", () => {
    const m: MetricDef = { ...def, thresholds: { P0: null, P1: 0.9, P2: 0.9 } };
    render(<table><tbody><MetricRow def={m} value={0.5} maturity="P0" /></tbody></table>);
    expect(screen.getByText(/measured/i)).toBeInTheDocument();
  });
});
```

- [ ] **Step 2: Run test to verify it fails**

Run: `cd frontend && npx vitest run src/components/eval/MetricRow.test.tsx`
Expected: FAIL — module not found.

- [ ] **Step 3: Write minimal implementation**

```tsx
// frontend/src/components/eval/StatusPill.tsx
import type { MetricStatus } from "../../lib/evalStatus";

const LABEL: Record<MetricStatus, string> = {
  pass: "Pass", fail: "Fail", measured_only: "Measured-only",
};

export function StatusPill({ status }: { status: MetricStatus }) {
  return <span className={`pill pill--${status}`} data-status={status}>{LABEL[status]}</span>;
}
```

```tsx
// frontend/src/components/eval/MetricRow.tsx
import { evalMetricStatus, type MetricDef, type Maturity } from "../../lib/evalStatus";
import { StatusPill } from "./StatusPill";

interface Props { def: MetricDef; value: number | null | undefined; maturity: Maturity; }

function fmtThreshold(def: MetricDef, m: Maturity): string {
  const v = def.thresholds[m];
  if (v === null || v === undefined) return "—";
  const cmp = def.comparator === "gte" ? "≥" : "≤";
  return def.unit === "%" ? `${cmp} ${(v * 100).toFixed(0)}%` : `${cmp} ${v}`;
}

function fmtValue(def: MetricDef, value: number | null | undefined): string {
  if (value === null || value === undefined) return "—";
  return def.unit === "%" ? `${(value * 100).toFixed(1)}%` : `${value}`;
}

export function MetricRow({ def, value, maturity }: Props) {
  const status = evalMetricStatus(def, value, maturity);
  return (
    <tr>
      <td>{def.label}</td>
      <td className="num">{fmtThreshold(def, maturity)}</td>
      <td className="num">{fmtValue(def, value)}</td>
      <td><StatusPill status={status} /></td>
    </tr>
  );
}
```

```tsx
// frontend/src/components/eval/LayerCard.tsx
import type { EvalLayer } from "../../data/evalFramework";
import type { Maturity } from "../../lib/evalStatus";
import { MetricRow } from "./MetricRow";

interface Props { layer: EvalLayer; values: Record<string, number>; maturity: Maturity; }

export function LayerCard({ layer, values, maturity }: Props) {
  return (
    <article className="layer-card">
      <header>
        <h3>{layer.title}</h3>
        <p>{layer.subtitle}</p>
        {layer.artifact !== "—" && <code>{layer.artifact}</code>}
      </header>
      {layer.metrics && (
        <table>
          <thead><tr><th>Metric</th><th>Ngưỡng</th><th>Giá trị</th><th>Trạng thái</th></tr></thead>
          <tbody>
            {layer.metrics.map((m) => (
              <MetricRow key={m.id} def={m} value={values[m.id]} maturity={maturity} />
            ))}
          </tbody>
        </table>
      )}
      {layer.invariants && (
        <ul className="invariants">{layer.invariants.map((i) => <li key={i}>{i}</li>)}</ul>
      )}
      {layer.rubricDimensions && (
        <ul className="rubric">{layer.rubricDimensions.map((d) => <li key={d}>{d}</li>)}</ul>
      )}
      {layer.blockingConditions && (
        <ul className="blocking">{layer.blockingConditions.map((b) => <li key={b}>{b}</li>)}</ul>
      )}
    </article>
  );
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `cd frontend && npx vitest run src/components/eval/MetricRow.test.tsx`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add frontend/src/components/eval/StatusPill.tsx frontend/src/components/eval/MetricRow.tsx frontend/src/components/eval/LayerCard.tsx frontend/src/components/eval/MetricRow.test.tsx
git commit -m "feat(frontend): status pill, metric row, layer card"
```

---

### Task 18: PipelineFlow + MaturityToggle + EvalDashboardPage

**Files:**
- Create: `frontend/src/components/eval/PipelineFlow.tsx`,
  `frontend/src/components/eval/MaturityToggle.tsx`,
  `frontend/src/pages/EvalDashboardPage.tsx`
- Test: `frontend/src/pages/EvalDashboardPage.test.tsx`

**REQUIRED SUB-SKILL:** frontend-design for the pipeline diagram, toggle, page layout, CI matrix +
maturity table styling, and the publication-readiness banner.

- [ ] **Step 1: Write the failing test**

```tsx
// frontend/src/pages/EvalDashboardPage.test.tsx
import { describe, it, expect } from "vitest";
import { render, screen, within } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { EvalDashboardPage } from "./EvalDashboardPage";

describe("EvalDashboardPage", () => {
  it("renders all 8 layer titles and the pipeline", () => {
    render(<EvalDashboardPage />);
    expect(screen.getByText(/1 · Data reliability/)).toBeInTheDocument();
    expect(screen.getByText(/6 · Report FPTS quality/)).toBeInTheDocument();
    expect(screen.getByText(/8 · Rollout & CI/)).toBeInTheDocument();
    expect(screen.getByText(/Client-final render authorization/)).toBeInTheDocument();
  });

  it("RAG hit-rate flips from measured-only at P0 to pass at P1", async () => {
    render(<EvalDashboardPage />);
    // At P0 (default), hit-rate@5 has no threshold -> measured-only present somewhere
    expect(screen.getAllByText(/measured/i).length).toBeGreaterThan(0);
    await userEvent.click(screen.getByRole("button", { name: "P1" }));
    // mock hit-rate 0.92 >= 0.9 -> a pass pill now exists for it
    expect(screen.getAllByText(/pass/i).length).toBeGreaterThan(0);
  });
});
```

- [ ] **Step 2: Run test to verify it fails**

Run: `cd frontend && npx vitest run src/pages/EvalDashboardPage.test.tsx`
Expected: FAIL — module not found.

- [ ] **Step 3: Write minimal implementation**

```tsx
// frontend/src/components/eval/MaturityToggle.tsx
import type { Maturity } from "../../lib/evalStatus";

const OPTIONS: Maturity[] = ["P0", "P1", "P2"];

export function MaturityToggle({ value, onChange }: { value: Maturity; onChange: (m: Maturity) => void }) {
  return (
    <div role="group" aria-label="maturity">
      {OPTIONS.map((m) => (
        <button key={m} aria-pressed={value === m} onClick={() => onChange(m)}>{m}</button>
      ))}
    </div>
  );
}
```

```tsx
// frontend/src/components/eval/PipelineFlow.tsx
import { PIPELINE_ORDER } from "../../data/evalFramework";

export function PipelineFlow() {
  return (
    <nav aria-label="fail-closed pipeline" className="pipeline">
      {PIPELINE_ORDER.map((stage, i) => (
        <span key={stage} className="pipeline__stage">
          {stage}{i < PIPELINE_ORDER.length - 1 ? " →" : ""}
        </span>
      ))}
      <p className="pipeline__rule">
        Một lớp deterministic critical fail không được LLM-judge ghi đè bằng điểm cao.
      </p>
    </nav>
  );
}
```

```tsx
// frontend/src/pages/EvalDashboardPage.tsx
import { useState } from "react";
import { EVAL_LAYERS, CI_GATE_MATRIX, MATURITY_TABLE } from "../data/evalFramework";
import { mockValuesForLayer, MOCK_ARTIFACTS } from "../mock";
import type { Maturity } from "../lib/evalStatus";
import { LayerCard } from "../components/eval/LayerCard";
import { MaturityToggle } from "../components/eval/MaturityToggle";
import { PipelineFlow } from "../components/eval/PipelineFlow";

export function EvalDashboardPage() {
  const [maturity, setMaturity] = useState<Maturity>("P0");
  const pub = MOCK_ARTIFACTS.publication_readiness;

  return (
    <section>
      <header>
        <h1>Khung đánh giá mô hình</h1>
        <MaturityToggle value={maturity} onChange={setMaturity} />
      </header>

      <PipelineFlow />

      <div className={`pub-banner ${pub.passed ? "ok" : "blocked"}`} role="status">
        Publication readiness: {pub.passed ? "PASS" : "BLOCKED"}
        {pub.blocking_reasons.length > 0 && <span> — {pub.blocking_reasons.join(", ")}</span>}
      </div>

      <div className="layer-grid">
        {EVAL_LAYERS.map((layer) => (
          <LayerCard key={layer.id} layer={layer} values={mockValuesForLayer(layer.id)} maturity={maturity} />
        ))}
      </div>

      <section aria-label="ci-gate-matrix">
        <h2>CI gate matrix</h2>
        <table>
          <thead><tr><th>Job</th><th>Scope</th><th>Block merge</th></tr></thead>
          <tbody>
            {CI_GATE_MATRIX.map((g) => (
              <tr key={g.job}><td>{g.job}</td><td>{g.scope}</td><td>{g.blockMerge}</td></tr>
            ))}
          </tbody>
        </table>
      </section>

      <section aria-label="maturity-thresholds">
        <h2>Ngưỡng chấp nhận theo độ chín</h2>
        <table>
          <thead><tr><th>Layer</th><th>P0</th><th>P1</th><th>P2</th></tr></thead>
          <tbody>
            {MATURITY_TABLE.map((r) => (
              <tr key={r.layer}><td>{r.layer}</td><td>{r.P0}</td><td>{r.P1}</td><td>{r.P2}</td></tr>
            ))}
          </tbody>
        </table>
      </section>
    </section>
  );
}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `cd frontend && npx vitest run src/pages/EvalDashboardPage.test.tsx`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add frontend/src/components/eval/PipelineFlow.tsx frontend/src/components/eval/MaturityToggle.tsx frontend/src/pages/EvalDashboardPage.tsx frontend/src/pages/EvalDashboardPage.test.tsx
git commit -m "feat(frontend): eval dashboard page (pipeline, maturity toggle, CI matrix, banner)"
```

---

## PHASE E — Shell, styling, build & serving

### Task 19: App shell + routing + design tokens

**Files:**
- Create: `frontend/src/App.tsx`, `frontend/src/components/common/Layout.tsx`,
  `frontend/src/styles/tokens.css`, `frontend/src/styles/global.css`
- Test: `frontend/src/App.test.tsx`

**REQUIRED SUB-SKILL:** frontend-design owns `tokens.css`/`global.css` and the visual nav/layout —
clean, scientific, monospace numerals, restrained palette + semantic status colors, signature
pipeline + status-pill treatment; no generic AI gradients.

**Mandatory typography requirements (do not deviate):**
- **Open Sans** is the primary UI font — it must render Vietnamese diacritics correctly. Self-host via
  `@fontsource/open-sans` (add to `package.json` deps; import `@fontsource/open-sans/latin.css` and
  `@fontsource/open-sans/vietnamese.css` in `main.tsx` or `global.css`). Do NOT rely on a CDN.
- Root base **`font-size: 17px`** (larger than the 16px default) for readability; build the type scale
  from there. Body text and table cells must remain comfortably legible at this base.
- A monospace family is used ONLY for numeric metric values (the `.num` cells), via a `--font-mono`
  token; everything else uses Open Sans via a `--font-sans` token.
- All visible UI text is Vietnamese (the components already use Vietnamese labels — keep them).
- Add `@fontsource/open-sans` to `frontend/package.json` dependencies as part of this task.

- [ ] **Step 1: Write the failing test**

```tsx
// frontend/src/App.test.tsx
import { describe, it, expect } from "vitest";
import { render, screen } from "@testing-library/react";
import { MemoryRouter } from "react-router-dom";
import App from "./App";

describe("App", () => {
  it("renders nav with both routes", () => {
    render(<MemoryRouter initialEntries={["/"]}><App /></MemoryRouter>);
    expect(screen.getByRole("link", { name: /báo cáo|reports/i })).toBeInTheDocument();
    expect(screen.getByRole("link", { name: /đánh giá|dashboard/i })).toBeInTheDocument();
  });
});
```

Note: `App` must not assume a router (main.tsx provides `BrowserRouter`; the test provides
`MemoryRouter`). `App` renders `<Routes>` only.

- [ ] **Step 2: Run test to verify it fails**

Run: `cd frontend && npx vitest run src/App.test.tsx`
Expected: FAIL — module not found.

- [ ] **Step 3: Write minimal implementation**

```tsx
// frontend/src/App.tsx
import { Routes, Route, Navigate } from "react-router-dom";
import { Layout } from "./components/common/Layout";
import { ReportsPage } from "./pages/ReportsPage";
import { EvalDashboardPage } from "./pages/EvalDashboardPage";

export default function App() {
  return (
    <Layout>
      <Routes>
        <Route path="/" element={<Navigate to="/reports" replace />} />
        <Route path="/reports" element={<ReportsPage />} />
        <Route path="/eval" element={<EvalDashboardPage />} />
      </Routes>
    </Layout>
  );
}
```

```tsx
// frontend/src/components/common/Layout.tsx
import { NavLink } from "react-router-dom";
import type { ReactNode } from "react";

export function Layout({ children }: { children: ReactNode }) {
  return (
    <div className="app-shell">
      <nav className="app-nav">
        <span className="app-brand">Pharma Equity Research</span>
        <NavLink to="/reports">Báo cáo</NavLink>
        <NavLink to="/eval">Khung đánh giá</NavLink>
      </nav>
      <main>{children}</main>
    </div>
  );
}
```

Create `frontend/src/styles/tokens.css` and `frontend/src/styles/global.css` with at minimum the
status-pill classes referenced by `StatusPill` (`.pill--pass`, `.pill--fail`, `.pill--measured_only`)
and base layout. (frontend-design refines the full system.)

- [ ] **Step 4: Run test to verify it passes**

Run: `cd frontend && npx vitest run src/App.test.tsx`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add frontend/src/App.tsx frontend/src/components/common/Layout.tsx frontend/src/styles frontend/src/App.test.tsx
git commit -m "feat(frontend): app shell, routing, design tokens"
```

---

### Task 20: Full frontend test + build

**Files:** none new.

- [ ] **Step 1: Run the full frontend test suite**

Run: `cd frontend && npm run test`
Expected: all test files PASS.

- [ ] **Step 2: Type-check + production build**

Run: `cd frontend && npm run build`
Expected: `tsc -b` clean, Vite emits `frontend/dist/`.

- [ ] **Step 3: Commit (lockfile / any fixes)**

```bash
git add frontend
git commit -m "chore(frontend): green test suite + production build"
```

---

### Task 21: Serve built frontend from FastAPI (prod path)

**Files:**
- Modify: `backend/api.py`
- Test: `tests/api/test_static_serving.py`

Mount `StaticFiles` at `/` with SPA fallback **after** all API routes so API paths win. Guard on the
dist dir existing so tests/dev without a build still work.

- [ ] **Step 1: Write the failing test**

```python
# tests/api/test_static_serving.py
from pathlib import Path
from fastapi.testclient import TestClient
from backend.api import create_app


def test_serves_spa_index_when_dist_present(tmp_path: Path):
    dist = tmp_path / "dist"
    dist.mkdir()
    (dist / "index.html").write_text("<!doctype html><title>app</title>", encoding="utf-8")
    app = create_app(check_schema_on_startup=False)
    app.state.frontend_dist = dist
    # static mount is wired lazily from state at app build; re-run wiring helper:
    from backend.api import mount_frontend
    mount_frontend(app, dist)
    client = TestClient(app)
    # unknown non-API path returns the SPA index (200), not 404
    resp = client.get("/eval")
    assert resp.status_code == 200
    assert "app" in resp.text
    # health (API) still works and is not shadowed
    assert client.get("/health").json()["status"] == "ok"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `python -m pytest tests/api/test_static_serving.py -v`
Expected: FAIL — `ImportError: cannot import name 'mount_frontend'`.

- [ ] **Step 3: Write minimal implementation**

Add to `backend/api.py` (module level, after `create_app`):

```python
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse as _FileResponse
from starlette.requests import Request


def mount_frontend(app: FastAPI, dist_dir: Path) -> None:
    """Serve a built Vite SPA. Call AFTER all API routes are registered."""
    dist_dir = Path(dist_dir)
    if not (dist_dir / "index.html").is_file():
        return
    assets = dist_dir / "assets"
    if assets.is_dir():
        app.mount("/assets", StaticFiles(directory=assets), name="assets")

    @app.get("/{full_path:path}")
    def spa_fallback(full_path: str, request: Request):
        candidate = (dist_dir / full_path).resolve()
        if candidate.is_file() and dist_dir.resolve() in candidate.parents:
            return _FileResponse(candidate)
        return _FileResponse(dist_dir / "index.html")
```

The `{full_path:path}` catch-all is registered last (lowest priority) only when `mount_frontend` is
called, so `/reports`, `/research/*`, `/health` declared in `create_app` keep precedence.

Replace the existing module-bottom `app = create_app(check_schema_on_startup=False)` line with the
wiring that also mounts the SPA when a build exists:

```python
app = create_app(check_schema_on_startup=False)
if (Path("frontend/dist") / "index.html").is_file():
    mount_frontend(app, Path("frontend/dist"))
```

- [ ] **Step 4: Run test to verify it passes**

Run: `python -m pytest tests/api/test_static_serving.py -v`
Expected: PASS.

- [ ] **Step 5: Commit**

```bash
git add backend/api.py tests/api/test_static_serving.py
git commit -m "feat(api): serve built Vite SPA with API-priority routing"
```

---

### Task 22: Dev docs + final verification

**Files:**
- Create: `frontend/README.md`

- [ ] **Step 1: Write `frontend/README.md`**

Document: prerequisites (Node 18+), `npm install`, `npm run dev` (proxies `/reports` + `/research`
to FastAPI on `:8000`), `npm run test`, `npm run build` (emits `dist/` served by FastAPI in prod),
and the API-path convention (no `/api` prefix; calls go to backend paths directly).

- [ ] **Step 2: Full backend suite for touched areas**

Run: `python -m pytest tests/reporting/test_output_inventory.py tests/api/test_reports_endpoints.py tests/api/test_static_serving.py -v`
Expected: all PASS.

- [ ] **Step 3: Full frontend suite**

Run: `cd frontend && npm run test`
Expected: all PASS.

- [ ] **Step 4: Manual smoke (optional, requires DB for generation only)**

Run backend: `uvicorn backend.api:app --port 8000`; run `cd frontend && npm run dev`; open
`http://localhost:5173` — Reports page lists 53 tickers with DHG showing report+explanation+preview;
Dashboard shows 8 layers, pipeline, maturity toggle flipping RAG status, CI matrix, maturity table.

- [ ] **Step 5: Commit**

```bash
git add frontend/README.md
git commit -m "docs(frontend): dev/build/serve instructions"
```

---

## Self-Review Notes

- **Spec coverage:** Reports list/preview/download/generate (Tasks 3–5, 11–13); 8-layer dashboard
  with thresholds/status/maturity (Tasks 14–18); fail-closed pipeline + CI matrix + maturity table +
  publication banner (Tasks 15, 18); no `/api` prefix + dev proxy + prod static serving (Tasks 6, 21);
  extensible filename resolver + numeric `preview_pages` (Task 1); `run_type=full_report` + RunStatus
  mapping from the real enum (Tasks 7, 8, 11). `/eval/framework` correctly deferred to P1 (not in
  this plan).
- **Type consistency:** `MetricDef`, `Maturity`, `MetricStatus`, `ReportItem`, `RunStatus`,
  `ReportFilterState` are defined once and reused. Metric `id`s in `evalFramework.ts` match the keys
  in `mock/index.ts` `LAYER_VALUE_MAP` and the layer ids passed to `mockValuesForLayer`.
- **Placeholder scan:** styling of presentational components is intentionally delegated to the
  frontend-design skill (called out per task) rather than left vague — this is a scope decision, not a
  placeholder. All logic, tests, types, and contracts are fully specified.
