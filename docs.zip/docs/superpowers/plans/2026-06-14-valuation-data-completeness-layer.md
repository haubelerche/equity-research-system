# Valuation Data Completeness Layer Implementation Plan

> **For agentic workers:** REQUIRED SUB-SKILL: Use superpowers:subagent-driven-development (recommended) or superpowers:executing-plans to implement this plan task-by-task. Steps use checkbox (`- [ ]`) syntax for tracking.

**Goal:** Make valuation report *which method needs which field, whether the field is present, and why it is missing* — and fix the root-cause ingestion gap that silently blocks FCFE on every ticker.

**Architecture:** Two layers. (1) **Root-cause fix** — register the two cash-flow-statement financing line items (`proceeds_from_borrowings.total`, `repayment_of_borrowings.total`) that `debt_schedule.py` already reads but that are dropped at ingestion because no canonical key / taxonomy alias / `ref.line_items` row exists; once ingested, the debt schedule reaches `direct_cash_flow` (high confidence) and FCFE becomes publishable instead of being blocked forever. (2) **Declarative pre-valuation layer** — a per-method `VALUATION_DATA_REQUIREMENTS` registry + a `DataAvailabilityMatrix` + a `data_gap_report`, run as a pre-flight before any valuation method executes, so missing inputs are diagnosed explicitly upfront instead of failing implicitly downstream.

**Scope note (verified, not assumed):** The system already has lineage (`FactEntry` with `source_uri`/`source_tier`/`confidence`/`ingested_at`), unit normalization + hard validation (`metric_metadata.validate_and_normalize` rejects no-unit / unknown-metric facts), source tiering (`facts/completeness.py`), and post-valuation publishability with no silent fallback (`valuation_method_policy.build_valuation_publishability_policy` — blocked methods, blend-only-from-publishable, sensitivity/bridge gates). This plan does NOT rebuild any of those. It adds only the genuinely-missing *declarative, per-method, pre-valuation* requirement check, and fixes the one ingestion gap.

**Tech Stack:** Python 3.12, pytest, PostgreSQL (Supabase) migrations, pandas (vnstock connector), YAML taxonomy.

---

## File Structure

**Created:**
- `backend/valuation/__init__.py` — new package for declarative valuation-input contracts.
- `backend/valuation/data_requirements.py` — `MethodRequirement` dataclass + `VALUATION_DATA_REQUIREMENTS` registry (FCFF / FCFE / P/E / EV-EBITDA). One responsibility: declare what each method needs.
- `backend/valuation/data_availability.py` — `build_data_availability_matrix()`, `build_data_gap_report()`, `run_valuation_preflight()`. One responsibility: compare the registry against a real `FactTable` + available assumptions/market-data and report readiness + gaps.
- `backend/database/migrations/041_seed_borrowing_line_items.sql` — register the two financing codes in `ref.line_items` (FK target for `ingest.observations.metric`).
- Tests: `tests/unit/test_borrowing_line_items_metadata.py`, `tests/unit/test_borrowing_alias_map.py`, `tests/unit/test_migration_041_borrowing_seed.py`, `tests/unit/test_debt_schedule_direct_cash_flow.py`, `tests/unit/test_valuation_data_requirements.py`, `tests/unit/test_data_availability_matrix.py`, `tests/unit/test_data_gap_report.py`, `tests/unit/test_valuation_preflight_wiring.py`, `tests/unit/test_data_completeness_regression.py`.

**Modified:**
- `backend/facts/metric_metadata.py:211-218` — add the two financing metrics to `METRIC_METADATA` (cash-flow section).
- `config/dataset/taxonomy/financial_taxonomy_vn_pharma.yaml:213` — add the two line items with Vietnamese aliases (after `financing_cash_flow.total`).
- `scripts/run_valuation.py:300-302` — call `run_valuation_preflight()` and attach `data_completeness` + `data_gap_report` to the artifact.

---

## Task 1: Register the two financing metrics in `metric_metadata.py`

**Why:** `build_fact_table()` calls `validate_and_normalize(line_item_code, ...)` which `reject`s any `metric_id` not in `METRIC_METADATA`. `debt_schedule.py:326-327` reads `proceeds_from_borrowings.total` / `repayment_of_borrowings.total`, but they are not registered, so they are dropped → debt schedule can never use `direct_cash_flow`.

**Files:**
- Modify: `backend/facts/metric_metadata.py:211-218`
- Test: `tests/unit/test_borrowing_line_items_metadata.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/unit/test_borrowing_line_items_metadata.py
"""The two CFS financing line items must be registered so they survive ingestion."""
from __future__ import annotations

from backend.facts.metric_metadata import (
    SemanticType,
    get_semantic_type,
    is_known_metric,
    validate_and_normalize,
)

PROCEEDS = "proceeds_from_borrowings.total"
REPAYMENT = "repayment_of_borrowings.total"


def test_financing_line_items_are_known_metrics():
    assert is_known_metric(PROCEEDS)
    assert is_known_metric(REPAYMENT)


def test_financing_line_items_are_monetary():
    assert get_semantic_type(PROCEEDS) is SemanticType.MONETARY
    assert get_semantic_type(REPAYMENT) is SemanticType.MONETARY


def test_financing_line_items_normalize_billion_vnd():
    # 1.5 tỷ → 1_500_000_000 absolute VND (canonical monetary contract)
    norm = validate_and_normalize(PROCEEDS, 1.5, "tỷ")
    assert norm.status == "ok"
    assert norm.value == 1_500_000_000.0


def test_financing_line_items_reject_when_unit_missing():
    norm = validate_and_normalize(REPAYMENT, 1.5, None)
    assert norm.status == "reject"
```

- [ ] **Step 2: Run test to verify it fails**

Run: `python -m pytest tests/unit/test_borrowing_line_items_metadata.py -v`
Expected: FAIL — `test_financing_line_items_are_known_metrics` asserts False (keys not registered).

- [ ] **Step 3: Add the metrics to the cash-flow section**

In `backend/facts/metric_metadata.py`, inside `METRIC_METADATA`, in the `# --- Cash flow (monetary) ---` block, after the `net_borrowing.total` line (currently line 217), add:

```python
    "net_borrowing.total": _m(SemanticType.MONETARY),
    # Gross CFS financing lines — required for high-confidence FCFE net borrowing.
    # debt_schedule.build_historical_debt_schedule() reads these to reach
    # method="direct_cash_flow"; without them it falls back to balance_sheet_delta
    # (medium) and FCFE is blocked from publication.
    "proceeds_from_borrowings.total": _m(SemanticType.MONETARY),
    "repayment_of_borrowings.total": _m(SemanticType.MONETARY),
    "change_in_working_capital.total": _m(SemanticType.MONETARY),
```

(Replace the existing two lines `"net_borrowing.total": ...` and `"change_in_working_capital.total": ...` so the two new lines sit between them; do not duplicate `change_in_working_capital.total`.)

- [ ] **Step 4: Run test to verify it passes**

Run: `python -m pytest tests/unit/test_borrowing_line_items_metadata.py -v`
Expected: PASS (4 tests).

- [ ] **Step 5: Commit**

```bash
git add backend/facts/metric_metadata.py tests/unit/test_borrowing_line_items_metadata.py
git commit -m "feat: register CFS financing line items so they survive ingestion"
```

---

## Task 2: Add the two line items to the taxonomy with Vietnamese aliases

**Why:** `vnstock_finance_connector._build_alias_map()` builds a `slug → (taxonomy_key, unit)` map from the taxonomy's `taxonomy_key`, `aliases`, and `label_vi`. Only keys present in the taxonomy get resolved from raw vnstock CFS rows. Adding the entries with the real Vietnamese labels makes "Tiền thu từ đi vay" / "Tiền trả nợ gốc vay" resolve automatically.

**Files:**
- Modify: `config/dataset/taxonomy/financial_taxonomy_vn_pharma.yaml:213` (after `financing_cash_flow.total`)
- Test: `tests/unit/test_borrowing_alias_map.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/unit/test_borrowing_alias_map.py
"""vnstock CFS financing rows must resolve to the new canonical codes."""
from __future__ import annotations

import pandas as pd

from scripts.connectors.vnstock_finance_connector import _build_alias_map, _resolve_label

PROCEEDS = "proceeds_from_borrowings.total"
REPAYMENT = "repayment_of_borrowings.total"


def _row(primary: str, en: str, item_id: str) -> "pd.Series[str]":
    return pd.Series({"primary": primary, "en": en, "id": item_id})


def test_proceeds_from_borrowings_resolves():
    alias = _build_alias_map(statement="cash_flow")
    resolved = _resolve_label(
        _row("Tiền thu từ đi vay", "Proceeds from borrowings", "proceeds_from_borrowings"),
        alias,
    )
    assert resolved is not None
    assert resolved[0] == PROCEEDS


def test_repayment_of_borrowings_resolves():
    alias = _build_alias_map(statement="cash_flow")
    resolved = _resolve_label(
        _row("Tiền trả nợ gốc vay", "Repayment of borrowings", "repayment_of_borrowings"),
        alias,
    )
    assert resolved is not None
    assert resolved[0] == REPAYMENT
```

- [ ] **Step 2: Run test to verify it fails**

Run: `python -m pytest tests/unit/test_borrowing_alias_map.py -v`
Expected: FAIL — `resolved is None` (no taxonomy entry for these labels).

- [ ] **Step 3: Add the taxonomy entries**

In `config/dataset/taxonomy/financial_taxonomy_vn_pharma.yaml`, immediately after the `financing_cash_flow.total:` block (ends at line 213), add:

```yaml
  proceeds_from_borrowings.total:
    label_vi: Tien thu tu di vay
    statement: cash_flow
    unit: vnd_bn
    # Slug: "Tiền thu từ đi vay" → tien_thu_tu_di_vay
    aliases: [tien_thu_tu_di_vay, tien_vay_ngan_han_dai_han_nhan_duoc, proceeds_from_borrowings, proceeds_from_borrowing]

  repayment_of_borrowings.total:
    label_vi: Tien tra no goc vay
    statement: cash_flow
    unit: vnd_bn
    # Slug: "Tiền trả nợ gốc vay" → tien_tra_no_goc_vay
    aliases: [tien_tra_no_goc_vay, tien_chi_tra_no_goc_vay, repayment_of_borrowings, repayment_of_borrowing]
```

- [ ] **Step 4: Run test to verify it passes**

Run: `python -m pytest tests/unit/test_borrowing_alias_map.py -v`
Expected: PASS (2 tests).

- [ ] **Step 5: Commit**

```bash
git add config/dataset/taxonomy/financial_taxonomy_vn_pharma.yaml tests/unit/test_borrowing_alias_map.py
git commit -m "feat: map vnstock CFS financing rows to canonical borrowing codes"
```

---

## Task 3: Migration 041 — seed `ref.line_items` for the two financing codes

**Why:** `ingest.observations.metric` has a FK to `ref.line_items(line_item_code)`. The connector now emits these two metrics; without a registry row the observation insert fails with `observations_metric_fkey`. Mirrors migration `036_seed_missing_line_items.sql`.

**Files:**
- Create: `backend/database/migrations/041_seed_borrowing_line_items.sql`
- Test: `tests/unit/test_migration_041_borrowing_seed.py` (static file assertion — no DB needed)

- [ ] **Step 1: Write the failing test**

```python
# tests/unit/test_migration_041_borrowing_seed.py
"""Migration 041 must register both financing codes in ref.line_items."""
from __future__ import annotations

from pathlib import Path

MIGRATION = (
    Path(__file__).resolve().parents[2]
    / "backend" / "database" / "migrations" / "041_seed_borrowing_line_items.sql"
)


def test_migration_file_exists():
    assert MIGRATION.exists()


def test_migration_seeds_both_codes_idempotently():
    sql = MIGRATION.read_text(encoding="utf-8")
    assert "proceeds_from_borrowings.total" in sql
    assert "repayment_of_borrowings.total" in sql
    assert "ref.line_items" in sql
    assert "ON CONFLICT" in sql  # idempotent re-run
```

- [ ] **Step 2: Run test to verify it fails**

Run: `python -m pytest tests/unit/test_migration_041_borrowing_seed.py -v`
Expected: FAIL — `test_migration_file_exists` (file absent).

- [ ] **Step 3: Write the migration**

```sql
-- backend/database/migrations/041_seed_borrowing_line_items.sql
-- Register the gross CFS financing lines emitted by the vnstock finance connector.
-- ingest.observations.metric FK-references ref.line_items(line_item_code); without
-- these rows the inserts fail with observations_metric_fkey. These two metrics let
-- the debt schedule reach method=direct_cash_flow (high confidence), which unblocks
-- FCFE publication. Idempotent: ON CONFLICT keeps the registry current.

INSERT INTO ref.line_items
    (line_item_code, statement_type, display_name_vi, display_name_en, canonical_unit, is_derived)
VALUES
    ('proceeds_from_borrowings.total', 'cash_flow', N'Tiền thu từ đi vay',    'Proceeds from borrowings', 'vnd_bn', FALSE),
    ('repayment_of_borrowings.total',  'cash_flow', N'Tiền trả nợ gốc vay',   'Repayment of borrowings',  'vnd_bn', FALSE)
ON CONFLICT (line_item_code) DO UPDATE
SET statement_type  = EXCLUDED.statement_type,
    display_name_vi = EXCLUDED.display_name_vi,
    display_name_en = EXCLUDED.display_name_en,
    canonical_unit  = EXCLUDED.canonical_unit;
```

- [ ] **Step 4: Run test to verify it passes**

Run: `python -m pytest tests/unit/test_migration_041_borrowing_seed.py -v`
Expected: PASS (3 tests).

- [ ] **Step 5: Apply the migration to the database**

Run the project's migration applier (same mechanism used for 036–040). If applied manually via psql:
Run: `psql "$DATABASE_URL" -f backend/database/migrations/041_seed_borrowing_line_items.sql`
Expected: `INSERT 0 2` (or `INSERT 0 0` + updates on idempotent re-run), no FK error.

- [ ] **Step 6: Commit**

```bash
git add backend/database/migrations/041_seed_borrowing_line_items.sql tests/unit/test_migration_041_borrowing_seed.py
git commit -m "feat: seed ref.line_items for CFS borrowing codes (migration 041)"
```

---

## Task 4: Regression — debt schedule reaches `direct_cash_flow` when financing facts exist

**Why:** Lock in that, once the financing facts flow through ingestion, `build_historical_debt_schedule()` produces a high-confidence `direct_cash_flow` row (and therefore `is_fcfe_publishable` can become True). The consumer code already exists; this guards the end-to-end unblock.

**Files:**
- Test: `tests/unit/test_debt_schedule_direct_cash_flow.py`

- [ ] **Step 1: Write the test**

```python
# tests/unit/test_debt_schedule_direct_cash_flow.py
"""With proceeds/repayment facts present, the debt schedule is high-confidence."""
from __future__ import annotations

from backend.facts.normalizer import FactEntry
from backend.analytics.debt_schedule import build_historical_debt_schedule


def _entry(value: float) -> FactEntry:
    return FactEntry(value=value, source_id="vnstock_cfs", source_tier=3, confidence=0.9)


def test_direct_cash_flow_method_when_financing_facts_present():
    # VND bn (analytics contract). 2024 borrowings = 100 drawn, 60 repaid.
    fact_table = {
        "total_debt.ending": {"2023FY": _entry(50.0), "2024FY": _entry(90.0)},
        "proceeds_from_borrowings.total": {"2024FY": _entry(100.0)},
        "repayment_of_borrowings.total": {"2024FY": _entry(60.0)},
        "interest_expense.total": {"2024FY": _entry(5.0)},
    }
    rows = build_historical_debt_schedule("DHG", fact_table, ["2023FY", "2024FY"])
    row_2024 = next(r for r in rows if r.label == "2024FY")
    assert row_2024.method == "direct_cash_flow"
    assert row_2024.confidence == "high"
    # net_borrowing = proceeds - abs(repayment) = 100 - 60 = 40
    assert row_2024.net_borrowing == 40.0


def test_falls_back_to_balance_sheet_delta_without_financing_facts():
    fact_table = {
        "total_debt.ending": {"2023FY": _entry(50.0), "2024FY": _entry(90.0)},
    }
    rows = build_historical_debt_schedule("DHG", fact_table, ["2023FY", "2024FY"])
    row_2024 = next(r for r in rows if r.label == "2024FY")
    assert row_2024.method == "balance_sheet_delta"
    assert row_2024.confidence == "medium"
```

- [ ] **Step 2: Run test to verify it passes**

Run: `python -m pytest tests/unit/test_debt_schedule_direct_cash_flow.py -v`
Expected: PASS (2 tests). The consumer logic already exists at `backend/analytics/debt_schedule.py:326-347`; if either assertion fails, fix the test fixture (not the engine) to match the real `_get(... "proceeds_from_borrowings.total" ...)` keys.

- [ ] **Step 3: Commit**

```bash
git add tests/unit/test_debt_schedule_direct_cash_flow.py
git commit -m "test: lock in direct_cash_flow debt schedule from CFS financing facts"
```

---

## Task 5: Per-method requirement registry (`data_requirements.py`)

**Files:**
- Create: `backend/valuation/__init__.py`
- Create: `backend/valuation/data_requirements.py`
- Test: `tests/unit/test_valuation_data_requirements.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/unit/test_valuation_data_requirements.py
from __future__ import annotations

from backend.valuation.data_requirements import (
    VALUATION_DATA_REQUIREMENTS,
    MethodRequirement,
    get_requirement,
)


def test_all_four_methods_registered():
    assert set(VALUATION_DATA_REQUIREMENTS) == {"fcff_dcf", "fcfe_dcf", "pe", "ev_ebitda"}


def test_fcfe_requires_gross_financing_lines():
    req = get_requirement("fcfe_dcf")
    assert "proceeds_from_borrowings.total" in req.required_facts
    assert "repayment_of_borrowings.total" in req.required_facts
    assert "operating_cash_flow.total" in req.required_facts
    assert "capex.total" in req.required_facts
    assert "shares_outstanding.ending" in req.required_facts
    assert "cost_of_equity" in req.required_assumptions
    assert "market_price" in req.required_market_data


def test_requirements_use_registered_canonical_keys():
    # Every required_fact must be a known canonical metric (else it can never be present).
    from backend.facts.metric_metadata import is_known_metric
    for req in VALUATION_DATA_REQUIREMENTS.values():
        for fact in req.required_facts:
            assert is_known_metric(fact), f"{req.method}: unknown canonical key {fact}"


def test_get_requirement_unknown_method_raises():
    import pytest
    with pytest.raises(KeyError):
        get_requirement("dividend_discount")


def test_requirement_is_frozen():
    req = get_requirement("pe")
    assert isinstance(req, MethodRequirement)
```

- [ ] **Step 2: Run test to verify it fails**

Run: `python -m pytest tests/unit/test_valuation_data_requirements.py -v`
Expected: FAIL — `ModuleNotFoundError: backend.valuation`.

- [ ] **Step 3: Create the package and registry**

```python
# backend/valuation/__init__.py
"""Declarative valuation-input contracts (requirements + availability)."""
```

```python
# backend/valuation/data_requirements.py
"""Per-method data requirement registry.

Declares, for each valuation method, the canonical facts / assumptions / market
data it needs BEFORE it may run. Field names are the project's canonical metric
keys (see backend/facts/metric_metadata.py), not generic placeholders.

BLEND is intentionally absent: it is a composite gated AFTER valuation by
backend/valuation_method_policy.build_valuation_publishability_policy (blend is
publishable only from already-publishable sub-methods). Duplicating that here
would create two sources of truth.
"""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class MethodRequirement:
    method: str
    required_facts: tuple[str, ...]
    required_assumptions: tuple[str, ...] = field(default_factory=tuple)
    required_market_data: tuple[str, ...] = field(default_factory=tuple)


VALUATION_DATA_REQUIREMENTS: dict[str, MethodRequirement] = {
    "fcff_dcf": MethodRequirement(
        method="fcff_dcf",
        required_facts=(
            "revenue.net",
            "ebit.total",
            "tax_expense.total",
            "da.total",
            "capex.total",
            "change_in_working_capital.total",
            "cash_and_equivalents.ending",
            "short_term_debt.ending",
            "long_term_debt.ending",
            "shares_outstanding.ending",
        ),
        required_assumptions=("wacc", "terminal_growth", "forecast_years"),
        required_market_data=("market_price",),
    ),
    "fcfe_dcf": MethodRequirement(
        method="fcfe_dcf",
        required_facts=(
            "operating_cash_flow.total",
            "capex.total",
            "proceeds_from_borrowings.total",
            "repayment_of_borrowings.total",
            "shares_outstanding.ending",
        ),
        required_assumptions=("cost_of_equity", "terminal_growth", "forecast_years"),
        required_market_data=("market_price",),
    ),
    "pe": MethodRequirement(
        method="pe",
        required_facts=(
            "eps.basic",
            "shares_outstanding.ending",
        ),
        required_market_data=("market_price", "peer_pe_median", "peer_group"),
    ),
    "ev_ebitda": MethodRequirement(
        method="ev_ebitda",
        required_facts=(
            "ebit.total",
            "da.total",
            "cash_and_equivalents.ending",
            "short_term_debt.ending",
            "long_term_debt.ending",
            "shares_outstanding.ending",
        ),
        required_market_data=("market_price", "peer_ev_ebitda_median", "peer_group"),
    ),
}


def get_requirement(method: str) -> MethodRequirement:
    """Return the requirement for a method, or raise KeyError if unknown."""
    return VALUATION_DATA_REQUIREMENTS[method]
```

- [ ] **Step 4: Run test to verify it passes**

Run: `python -m pytest tests/unit/test_valuation_data_requirements.py -v`
Expected: PASS (5 tests). If `test_requirements_use_registered_canonical_keys` fails on `da.total`, confirm it exists in `METRIC_METADATA` (it does, line 181) — do not weaken the test.

- [ ] **Step 5: Commit**

```bash
git add backend/valuation/__init__.py backend/valuation/data_requirements.py tests/unit/test_valuation_data_requirements.py
git commit -m "feat: add per-method valuation data requirement registry"
```

---

## Task 6: Data availability matrix (`data_availability.py`)

**Files:**
- Create: `backend/valuation/data_availability.py`
- Test: `tests/unit/test_data_availability_matrix.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/unit/test_data_availability_matrix.py
from __future__ import annotations

from backend.facts.normalizer import FactEntry
from backend.valuation.data_availability import build_data_availability_matrix


def _entry(value: float, uri: str = "https://src", conf: float = 0.9) -> FactEntry:
    return FactEntry(value=value, source_id="s", source_uri=uri, source_tier=1, confidence=conf)


def _fcfe_complete_table() -> dict:
    p = "2024FY"
    return {
        "operating_cash_flow.total": {p: _entry(500.0)},
        "capex.total": {p: _entry(-80.0)},
        "proceeds_from_borrowings.total": {p: _entry(100.0)},
        "repayment_of_borrowings.total": {p: _entry(60.0)},
        "shares_outstanding.ending": {p: _entry(130.7)},
    }


def test_fcfe_ready_when_all_facts_present():
    matrix = build_data_availability_matrix(
        ticker="DHG",
        fact_table=_fcfe_complete_table(),
        latest_period="2024FY",
        available_assumptions={"cost_of_equity", "terminal_growth", "forecast_years"},
        available_market_data={"market_price"},
    )
    fcfe = matrix["fcfe_dcf"]
    assert fcfe["status"] == "ready"
    assert fcfe["missing_fields"] == []
    assert fcfe["available_count"] == fcfe["required_count"]


def test_fcfe_blocked_lists_exact_missing_financing_fields():
    table = _fcfe_complete_table()
    del table["proceeds_from_borrowings.total"]
    del table["repayment_of_borrowings.total"]
    matrix = build_data_availability_matrix(
        ticker="DHG",
        fact_table=table,
        latest_period="2024FY",
        available_assumptions={"cost_of_equity", "terminal_growth", "forecast_years"},
        available_market_data={"market_price"},
    )
    fcfe = matrix["fcfe_dcf"]
    assert fcfe["status"] == "blocked"
    assert set(fcfe["missing_fields"]) == {
        "proceeds_from_borrowings.total",
        "repayment_of_borrowings.total",
    }


def test_field_detail_carries_lineage_for_present_facts():
    matrix = build_data_availability_matrix(
        ticker="DHG",
        fact_table=_fcfe_complete_table(),
        latest_period="2024FY",
        available_assumptions={"cost_of_equity", "terminal_growth", "forecast_years"},
        available_market_data={"market_price"},
    )
    detail = {d["canonical_field"]: d for d in matrix["fcfe_dcf"]["field_details"]}
    cfo = detail["operating_cash_flow.total"]
    assert cfo["available"] is True
    assert cfo["latest_period"] == "2024FY"
    assert cfo["source_uri"] == "https://src"
    assert cfo["confidence"] == 0.9
    assert cfo["classification"] == "available"


def test_missing_assumption_and_market_data_block_method():
    matrix = build_data_availability_matrix(
        ticker="DHG",
        fact_table=_fcfe_complete_table(),
        latest_period="2024FY",
        available_assumptions=set(),          # no assumptions supplied
        available_market_data=set(),          # no market price
    )
    fcfe = matrix["fcfe_dcf"]
    assert fcfe["status"] == "blocked"
    assert "cost_of_equity" in fcfe["missing_fields"]
    assert "market_price" in fcfe["missing_fields"]


def test_pe_blocked_on_missing_peer_market_data():
    table = {
        "eps.basic": {"2024FY": _entry(5000.0)},
        "shares_outstanding.ending": {"2024FY": _entry(130.7)},
    }
    matrix = build_data_availability_matrix(
        ticker="DHG",
        fact_table=table,
        latest_period="2024FY",
        available_assumptions=set(),
        available_market_data={"market_price"},  # peer data absent
    )
    pe = matrix["pe"]
    assert pe["status"] == "blocked"
    assert "peer_pe_median" in pe["missing_fields"]
    assert "peer_group" in pe["missing_fields"]
```

- [ ] **Step 2: Run test to verify it fails**

Run: `python -m pytest tests/unit/test_data_availability_matrix.py -v`
Expected: FAIL — `ImportError: cannot import name 'build_data_availability_matrix'`.

- [ ] **Step 3: Implement the matrix**

```python
# backend/valuation/data_availability.py
"""Pre-valuation data availability matrix + gap report.

Compares VALUATION_DATA_REQUIREMENTS against a real FactTable (plus the set of
assumptions and market-data inputs the caller can supply) and reports, per
method, exactly which inputs are present and which are missing — BEFORE any
method runs. No fabrication: a field is 'available' only if a real FactEntry
exists for the latest period.
"""
from __future__ import annotations

from typing import Any

from backend.facts.metric_metadata import is_known_metric
from backend.facts.normalizer import FactTable
from backend.valuation.data_requirements import VALUATION_DATA_REQUIREMENTS


def _classify_missing_fact(canonical_field: str) -> str:
    """Best-effort, deterministic attribution for a missing fact.

    We can honestly distinguish only two cases without the raw-extraction log:
      - the canonical key is not even registered  → canonical_mapping_missing
      - the key is registered but no fact ingested → ingestion_or_source_absence
    Finer parser-vs-source attribution requires the connector's raw rows and is
    intentionally not guessed here.
    """
    if not is_known_metric(canonical_field):
        return "canonical_mapping_missing"
    return "ingestion_or_source_absence"


def _fact_detail(fact_table: FactTable, canonical_field: str, latest_period: str | None) -> dict[str, Any]:
    entry = None
    if latest_period is not None:
        entry = fact_table.get(canonical_field, {}).get(latest_period)
    if entry is not None:
        return {
            "canonical_field": canonical_field,
            "kind": "fact",
            "available": True,
            "latest_period": latest_period,
            "source_uri": entry.source_uri or None,
            "confidence": entry.confidence,
            "classification": "available",
        }
    return {
        "canonical_field": canonical_field,
        "kind": "fact",
        "available": False,
        "latest_period": None,
        "source_uri": None,
        "confidence": None,
        "classification": _classify_missing_fact(canonical_field),
    }


def _input_detail(name: str, present: bool, kind: str, missing_classification: str) -> dict[str, Any]:
    return {
        "canonical_field": name,
        "kind": kind,
        "available": present,
        "latest_period": None,
        "source_uri": None,
        "confidence": None,
        "classification": "available" if present else missing_classification,
    }


def build_data_availability_matrix(
    *,
    ticker: str,
    fact_table: FactTable,
    latest_period: str | None,
    available_assumptions: set[str],
    available_market_data: set[str],
) -> dict[str, dict[str, Any]]:
    """Return {method: availability_dict} for every registered method.

    availability_dict keys: method, required_count, available_count,
    missing_fields, field_details, status ('ready' | 'blocked').
    """
    matrix: dict[str, dict[str, Any]] = {}
    for method, req in VALUATION_DATA_REQUIREMENTS.items():
        details: list[dict[str, Any]] = []
        missing: list[str] = []

        for f in req.required_facts:
            d = _fact_detail(fact_table, f, latest_period)
            details.append(d)
            if not d["available"]:
                missing.append(f)

        for a in req.required_assumptions:
            present = a in available_assumptions
            details.append(_input_detail(a, present, "assumption", "missing_assumption"))
            if not present:
                missing.append(a)

        for md in req.required_market_data:
            present = md in available_market_data
            details.append(_input_detail(md, present, "market_data", "missing_market_data"))
            if not present:
                missing.append(md)

        required_count = (
            len(req.required_facts) + len(req.required_assumptions) + len(req.required_market_data)
        )
        available_count = required_count - len(missing)
        matrix[method] = {
            "method": method,
            "ticker": ticker,
            "required_count": required_count,
            "available_count": available_count,
            "missing_fields": missing,
            "field_details": details,
            "status": "ready" if not missing else "blocked",
        }
    return matrix
```

- [ ] **Step 4: Run test to verify it passes**

Run: `python -m pytest tests/unit/test_data_availability_matrix.py -v`
Expected: PASS (5 tests).

- [ ] **Step 5: Commit**

```bash
git add backend/valuation/data_availability.py tests/unit/test_data_availability_matrix.py
git commit -m "feat: pre-valuation data availability matrix"
```

---

## Task 7: Data gap report (`build_data_gap_report`)

**Why:** improvement.md §P9 — for each missing field: which method, the classification, and a recommended fix.

**Files:**
- Modify: `backend/valuation/data_availability.py` (append `RECOMMENDED_FIXES` + `build_data_gap_report`)
- Test: `tests/unit/test_data_gap_report.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/unit/test_data_gap_report.py
from __future__ import annotations

from backend.facts.normalizer import FactEntry
from backend.valuation.data_availability import (
    build_data_availability_matrix,
    build_data_gap_report,
)


def _entry(v: float) -> FactEntry:
    return FactEntry(value=v, source_id="s", source_uri="u", confidence=0.9)


def test_gap_report_lists_missing_fcfe_financing_with_fix():
    table = {
        "operating_cash_flow.total": {"2024FY": _entry(500.0)},
        "capex.total": {"2024FY": _entry(-80.0)},
        "shares_outstanding.ending": {"2024FY": _entry(130.7)},
    }
    matrix = build_data_availability_matrix(
        ticker="DHG",
        fact_table=table,
        latest_period="2024FY",
        available_assumptions={"cost_of_equity", "terminal_growth", "forecast_years"},
        available_market_data={"market_price"},
    )
    report = build_data_gap_report(matrix)
    gaps = {(g["method"], g["field"]): g for g in report["gaps"]}
    key = ("fcfe_dcf", "proceeds_from_borrowings.total")
    assert key in gaps
    assert gaps[key]["classification"] == "ingestion_or_source_absence"
    assert "vnstock" in gaps[key]["recommended_fix"].lower() or "cfs" in gaps[key]["recommended_fix"].lower()


def test_gap_report_empty_when_all_ready():
    table = {
        "operating_cash_flow.total": {"2024FY": _entry(500.0)},
        "capex.total": {"2024FY": _entry(-80.0)},
        "proceeds_from_borrowings.total": {"2024FY": _entry(100.0)},
        "repayment_of_borrowings.total": {"2024FY": _entry(60.0)},
        "shares_outstanding.ending": {"2024FY": _entry(130.7)},
    }
    matrix = build_data_availability_matrix(
        ticker="DHG",
        fact_table=table,
        latest_period="2024FY",
        available_assumptions={"cost_of_equity", "terminal_growth", "forecast_years"},
        available_market_data={"market_price"},
    )
    # Only inspect fcfe_dcf to keep the assertion focused.
    report = build_data_gap_report({"fcfe_dcf": matrix["fcfe_dcf"]})
    assert report["gaps"] == []
    assert report["ready_methods"] == ["fcfe_dcf"]
```

- [ ] **Step 2: Run test to verify it fails**

Run: `python -m pytest tests/unit/test_data_gap_report.py -v`
Expected: FAIL — `ImportError: cannot import name 'build_data_gap_report'`.

- [ ] **Step 3: Implement the gap report**

Append to `backend/valuation/data_availability.py`:

```python
# Specific remediation hints keyed by canonical field; fall back to classification.
RECOMMENDED_FIXES: dict[str, str] = {
    "proceeds_from_borrowings.total": (
        "Ingest CFS financing line 'Tiền thu từ đi vay' via the vnstock finance "
        "connector (taxonomy alias + migration 041 registered)."
    ),
    "repayment_of_borrowings.total": (
        "Ingest CFS financing line 'Tiền trả nợ gốc vay' via the vnstock finance "
        "connector (taxonomy alias + migration 041 registered)."
    ),
    "peer_pe_median": "Supply a peer P/E dataset; until then P/E stays cross-check only.",
    "peer_ev_ebitda_median": "Supply a peer EV/EBITDA dataset; EV/EBITDA stays cross-check only.",
    "peer_group": "Define the peer group taxonomy for relative valuation.",
    "market_price": "Provide a current market price (vnstock VCI overview / price history).",
}

_CLASSIFICATION_FIXES: dict[str, str] = {
    "canonical_mapping_missing": (
        "Register the canonical key in metric_metadata.METRIC_METADATA and add a "
        "taxonomy alias + ref.line_items seed so it survives ingestion."
    ),
    "ingestion_or_source_absence": (
        "Verify the connector emits this metric for the latest period and the "
        "source actually publishes it; if absent at source, the method stays blocked."
    ),
    "missing_assumption": "Supply the assumption (analyst-approved or model default).",
    "missing_market_data": "Supply the market-data input from a market source.",
}


def build_data_gap_report(matrix: dict[str, dict[str, Any]]) -> dict[str, Any]:
    """Flatten a matrix into an actionable gap report (improvement.md §P9)."""
    gaps: list[dict[str, Any]] = []
    ready_methods: list[str] = []
    for method, avail in matrix.items():
        if avail["status"] == "ready":
            ready_methods.append(method)
            continue
        detail_by_field = {d["canonical_field"]: d for d in avail["field_details"]}
        for field_name in avail["missing_fields"]:
            classification = detail_by_field[field_name]["classification"]
            recommended = RECOMMENDED_FIXES.get(
                field_name, _CLASSIFICATION_FIXES.get(classification, "Investigate and source this input.")
            )
            gaps.append({
                "method": method,
                "field": field_name,
                "classification": classification,
                "recommended_fix": recommended,
            })
    return {"ready_methods": ready_methods, "gaps": gaps}
```

- [ ] **Step 4: Run test to verify it passes**

Run: `python -m pytest tests/unit/test_data_gap_report.py -v`
Expected: PASS (2 tests).

- [ ] **Step 5: Commit**

```bash
git add backend/valuation/data_availability.py tests/unit/test_data_gap_report.py
git commit -m "feat: actionable data gap report for blocked valuation methods"
```

---

## Task 8: Pre-flight orchestration + wire into `run_valuation`

**Why:** Run the matrix/gap-report before FCFF/FCFE execute and attach the result to the artifact, so the artifact carries an explicit, upfront `data_completeness` block (improvement.md §"Artifact bắt buộc trước valuation").

**Files:**
- Modify: `backend/valuation/data_availability.py` (add `run_valuation_preflight`)
- Modify: `scripts/run_valuation.py:300-302` (call it; attach to artifact)
- Test: `tests/unit/test_valuation_preflight_wiring.py`

- [ ] **Step 1: Write the failing test**

```python
# tests/unit/test_valuation_preflight_wiring.py
from __future__ import annotations

from backend.facts.normalizer import FactEntry
from backend.valuation.data_availability import run_valuation_preflight


def _entry(v: float) -> FactEntry:
    return FactEntry(value=v, source_id="s", source_uri="u", confidence=0.9)


def test_preflight_returns_matrix_and_gap_report():
    table = {
        "operating_cash_flow.total": {"2024FY": _entry(500.0)},
        "capex.total": {"2024FY": _entry(-80.0)},
        "shares_outstanding.ending": {"2024FY": _entry(130.7)},
    }
    result = run_valuation_preflight(
        ticker="DHG",
        fact_table=table,
        fy_periods=["2023FY", "2024FY"],
        current_price_vnd=92000.0,
        peer_dataset_available=False,
    )
    assert result["ticker"] == "DHG"
    assert result["valuation_date"]  # ISO string present
    assert "data_completeness" in result
    assert "data_gap_report" in result
    # FCFE blocked on missing financing lines; surfaced in the gap report.
    assert result["data_completeness"]["fcfe_dcf"]["status"] == "blocked"
    fcfe_missing = result["data_completeness"]["fcfe_dcf"]["missing_fields"]
    assert "proceeds_from_borrowings.total" in fcfe_missing


def test_preflight_market_price_absent_blocks_market_data():
    table = {"eps.basic": {"2024FY": _entry(5000.0)}, "shares_outstanding.ending": {"2024FY": _entry(130.7)}}
    result = run_valuation_preflight(
        ticker="DHG",
        fact_table=table,
        fy_periods=["2024FY"],
        current_price_vnd=None,
        peer_dataset_available=False,
    )
    assert "market_price" in result["data_completeness"]["pe"]["missing_fields"]
```

- [ ] **Step 2: Run test to verify it fails**

Run: `python -m pytest tests/unit/test_valuation_preflight_wiring.py -v`
Expected: FAIL — `ImportError: cannot import name 'run_valuation_preflight'`.

- [ ] **Step 3: Implement `run_valuation_preflight`**

Append to `backend/valuation/data_availability.py` (add `from datetime import UTC, datetime` to the imports at the top of the file):

```python
def run_valuation_preflight(
    *,
    ticker: str,
    fact_table: FactTable,
    fy_periods: list[str],
    current_price_vnd: float | None,
    peer_dataset_available: bool,
) -> dict[str, Any]:
    """Build the pre-valuation completeness artifact for a run.

    Assumptions (wacc/cost_of_equity/terminal_growth/forecast_years) are always
    supplied by the valuation engine as model defaults, so they are treated as
    present; the discriminating signal is fact + market-data availability.
    """
    latest_period = sorted(fy_periods)[-1] if fy_periods else None
    available_assumptions = {"wacc", "cost_of_equity", "terminal_growth", "forecast_years"}
    available_market_data: set[str] = set()
    if current_price_vnd is not None:
        available_market_data.add("market_price")
    if peer_dataset_available:
        available_market_data.update({"peer_pe_median", "peer_ev_ebitda_median", "peer_group"})

    matrix = build_data_availability_matrix(
        ticker=ticker,
        fact_table=fact_table,
        latest_period=latest_period,
        available_assumptions=available_assumptions,
        available_market_data=available_market_data,
    )
    return {
        "ticker": ticker,
        "valuation_date": datetime.now(UTC).isoformat(),
        "latest_period": latest_period,
        "data_completeness": matrix,
        "data_gap_report": build_data_gap_report(matrix),
    }
```

- [ ] **Step 4: Run the preflight test to verify it passes**

Run: `python -m pytest tests/unit/test_valuation_preflight_wiring.py -v`
Expected: PASS (2 tests).

- [ ] **Step 5: Wire into `run_valuation`**

In `scripts/run_valuation.py`, the shares-injection block ends at line 300 (`print(f"[run_valuation] WARNING: shares injection failed ...")`). Immediately AFTER that block and BEFORE the `# ── Ratio analysis ──` comment (line 302), insert:

```python
    # ── Pre-valuation data completeness (improvement.md §P0/P1) ──────────────
    # Diagnose, per method, exactly which canonical facts / assumptions / market
    # data are present before any method runs. Attached to the artifact so a
    # blocked method (e.g. FCFE missing CFS financing lines) is explained upfront
    # instead of failing implicitly downstream.
    from backend.valuation.data_availability import run_valuation_preflight
    _preflight_price = _get_current_price(ticker)
    preflight = run_valuation_preflight(
        ticker=ticker,
        fact_table=full_table,
        fy_periods=fy_periods,
        current_price_vnd=_preflight_price,
        peer_dataset_available=False,  # no peer dataset wired yet → P/E & EV/EBITDA stay cross-check
    )
    for _gap in preflight["data_gap_report"]["gaps"]:
        print(f"[run_valuation] DATA GAP {_gap['method']}: missing {_gap['field']} "
              f"({_gap['classification']}) — {_gap['recommended_fix']}")
```

Then, in the artifact dict (the `artifact = { ... }` literal beginning at line 829), add these two keys after `"current_price_vnd": current_price,` (line 865):

```python
        "current_price_vnd": current_price,
        "data_completeness": preflight["data_completeness"],
        "data_gap_report": preflight["data_gap_report"],
```

- [ ] **Step 6: Verify the wiring imports cleanly**

Run: `python -c "import ast,sys; ast.parse(open('scripts/run_valuation.py',encoding='utf-8').read()); print('run_valuation.py parses OK')"`
Expected: `run_valuation.py parses OK`

- [ ] **Step 7: Commit**

```bash
git add backend/valuation/data_availability.py scripts/run_valuation.py tests/unit/test_valuation_preflight_wiring.py
git commit -m "feat: attach pre-valuation data completeness + gap report to artifact"
```

---

## Task 9: Regression — synthetic-complete passes, real DHG/DBD honest

**Why:** improvement.md §P10 — the synthetic complete artifact must show all methods ready; DHG/DBD may remain blocked only when real required data is genuinely absent.

**Files:**
- Test: `tests/unit/test_data_completeness_regression.py`

- [ ] **Step 1: Write the test**

```python
# tests/unit/test_data_completeness_regression.py
"""End-to-end-ish regression for the data completeness layer.

Synthetic-complete table → every method ready.
Synthetic table missing the CFS financing lines → FCFE blocked with the exact
two missing fields (mirrors the real DHG/DBD condition before the ingestion fix).
"""
from __future__ import annotations

from backend.facts.normalizer import FactEntry
from backend.valuation.data_availability import run_valuation_preflight


def _e(v: float) -> FactEntry:
    return FactEntry(value=v, source_id="s", source_uri="https://audited", source_tier=0, confidence=0.95)


def _complete_table(period: str = "2024FY") -> dict:
    return {
        "revenue.net": {period: _e(4000.0)},
        "ebit.total": {period: _e(700.0)},
        "tax_expense.total": {period: _e(140.0)},
        "da.total": {period: _e(120.0)},
        "capex.total": {period: _e(-150.0)},
        "change_in_working_capital.total": {period: _e(30.0)},
        "cash_and_equivalents.ending": {period: _e(900.0)},
        "short_term_debt.ending": {period: _e(50.0)},
        "long_term_debt.ending": {period: _e(40.0)},
        "shares_outstanding.ending": {period: _e(130.7)},
        "operating_cash_flow.total": {period: _e(620.0)},
        "proceeds_from_borrowings.total": {period: _e(100.0)},
        "repayment_of_borrowings.total": {period: _e(60.0)},
        "eps.basic": {period: _e(5300.0)},
    }


def test_synthetic_complete_artifact_all_dcf_methods_ready():
    result = run_valuation_preflight(
        ticker="SYN",
        fact_table=_complete_table(),
        fy_periods=["2022FY", "2023FY", "2024FY"],
        current_price_vnd=92000.0,
        peer_dataset_available=True,  # synthetic supplies peers too
    )
    dc = result["data_completeness"]
    assert dc["fcff_dcf"]["status"] == "ready"
    assert dc["fcfe_dcf"]["status"] == "ready"
    assert dc["pe"]["status"] == "ready"
    assert dc["ev_ebitda"]["status"] == "ready"
    assert result["data_gap_report"]["gaps"] == []


def test_missing_cfs_financing_blocks_only_fcfe_financing_fields():
    table = _complete_table()
    del table["proceeds_from_borrowings.total"]
    del table["repayment_of_borrowings.total"]
    result = run_valuation_preflight(
        ticker="DHG",
        fact_table=table,
        fy_periods=["2022FY", "2023FY", "2024FY"],
        current_price_vnd=92000.0,
        peer_dataset_available=True,
    )
    dc = result["data_completeness"]
    # FCFF/PE/EV-EBITDA do not need the gross financing lines → still ready.
    assert dc["fcff_dcf"]["status"] == "ready"
    assert dc["fcfe_dcf"]["status"] == "blocked"
    assert set(dc["fcfe_dcf"]["missing_fields"]) == {
        "proceeds_from_borrowings.total",
        "repayment_of_borrowings.total",
    }
    # The gap report names the fix.
    fcfe_gaps = [g for g in result["data_gap_report"]["gaps"] if g["method"] == "fcfe_dcf"]
    assert len(fcfe_gaps) == 2
    assert all(g["classification"] == "ingestion_or_source_absence" for g in fcfe_gaps)
```

- [ ] **Step 2: Run test to verify it passes**

Run: `python -m pytest tests/unit/test_data_completeness_regression.py -v`
Expected: PASS (2 tests).

- [ ] **Step 3: Commit**

```bash
git add tests/unit/test_data_completeness_regression.py
git commit -m "test: data completeness regression (synthetic ready, missing CFS blocks FCFE)"
```

---

## Task 10: Full suite + merge to main

**Why:** Confirm no regressions across the existing ~1300+ tests before integrating. Per project convention (sole developer), merge directly to `main` — no PR.

**Files:** none (verification + integration only)

- [ ] **Step 1: Run the full unit suite**

Run: `python -m pytest tests/unit -q`
Expected: all pass (new tests included; no pre-existing tests broken by the metadata/taxonomy additions).

- [ ] **Step 2: Run any valuation/facts integration tests touched**

Run: `python -m pytest tests/unit/test_vnstock_finance_dedup.py tests/unit/test_debt_schedule.py tests/unit/test_debt_fcfe_gate.py -q`
Expected: all pass.

- [ ] **Step 3: Re-ingest a ticker to populate the new facts (DHG)**

Run the project's vnstock finance ingestion for DHG (same command used to populate other CFS lines), then rebuild facts. Expected: `proceeds_from_borrowings.total` and `repayment_of_borrowings.total` appear in the DHG fact set for recent FY periods (confirm via the run logs — no `observations_metric_fkey` error, no "Rejected fact proceeds_from_borrowings.total" in normalizer logs).

- [ ] **Step 4: Run a real valuation and inspect the new artifact block**

Run: `python scripts/run_valuation.py --ticker DHG`
Expected: stdout prints `DATA GAP` lines only for genuinely-absent inputs; `storage/runs/.../valuation.json` contains a `data_completeness` block where `fcfe_dcf.status == "ready"` IF the re-ingest populated the financing lines (otherwise it honestly reports them missing with the recommended fix).

- [ ] **Step 5: Merge to main**

```bash
git checkout main
git merge --no-ff <feature-branch>
git push origin main
```

---

## Self-Review

**Spec coverage (improvement.md):**
- §P0 Data Requirement Registry → Task 5 (`VALUATION_DATA_REQUIREMENTS`).
- §P1 Data Availability Matrix per ticker → Task 6.
- §P2 lineage per fact → already exists (`FactEntry`); surfaced in matrix `field_details` (source_uri/confidence/period). No rebuild.
- §P3 source tiering → already exists (`facts/completeness.py`, `source_tier`). Not duplicated.
- §P4 statement-complete ingestion → Tasks 1–3 close the specific missing CFS financing lines (the actual gap); income/balance/CFO statements already ingest.
- §P5 no silent fallback → already enforced (`is_fcfe_publishable`, `build_valuation_publishability_policy`); Task 4 regression-locks the high-confidence path the fix enables.
- §P6 Vietnamese line-item canonical mapping → Task 2 (proceeds/repayment aliases); other CFS items already mapped.
- §P7 unit normalization → already exists (`metric_metadata`); new metrics inherit MONETARY normalization (Task 1 test asserts it).
- §P8 hard validation (no fact without unit/source/period, no method without required facts) → unit/source already enforced at ingestion; "no method without required facts" is Task 6/8 (status='blocked' + missing_fields).
- §P9 data_gap_report for DHG/DBD → Task 7 + Task 10 step 4.
- §P10 regression with synthetic-complete + real DHG/DBD → Task 9 + Task 10.
- §"Artifact bắt buộc trước valuation" → Task 8 (`data_completeness` + `data_gap_report` on artifact).

**Deliberately not built (already in the codebase — would create a second source of truth):** generic lineage schema, unit normalizer, source priority tiers, post-valuation publishability/blend gating. Blend stays out of the pre-flight registry by design (gated post-valuation by `build_valuation_publishability_policy`).

**Type/name consistency:** `MethodRequirement` fields (`method`, `required_facts`, `required_assumptions`, `required_market_data`) are used identically in Tasks 5/6. Matrix dict keys (`status`, `missing_fields`, `field_details`, `available_count`, `required_count`) are consistent across Tasks 6/7/8/9. `run_valuation_preflight` signature in Task 8 matches its call in Task 8 step 5 and tests in Tasks 8/9. Canonical keys (`proceeds_from_borrowings.total`, `repayment_of_borrowings.total`, `da.total`, `operating_cash_flow.total`, `shares_outstanding.ending`) are identical in registry, tests, taxonomy, and migration.
