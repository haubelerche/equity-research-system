# Report Generation + Live Progress — Design

**Date:** 2026-06-14
**Status:** Approved (design); pending spec review
**Topic:** Make the deployed "Sinh báo cáo" / "Cập nhật" buttons actually generate a downloadable report, with a live Vietnamese progress modal.

---

## 1. Problem

On the deployed app (Vercel frontend → Railway backend), clicking **"Sinh báo cáo"** (generate) or **"Cập nhật"** (update) does not produce a usable result:

- **B1 (design gap):** `POST /research/start` runs the pipeline only up to a JSON "publishable model" and never renders a PDF. The download endpoints `GET /reports/{ticker}/file/{kind}` serve files from the local `output/` dir ([api.py:256-283](../../../backend/api.py)) produced only by a separate manual CLI (`scripts/generate_fast_report.py`). Railway's filesystem is ephemeral, so those PDFs never exist for the web app.
- **UX gap:** While a run is in progress the user sees only a bare "Đang chạy…" with no indication of what the system is doing.
- **Empty-ticker gap:** For a ticker with no data in the database, the user wants the system to actively collect data from sources (CafeF, vnstock, official disclosures) and *show* that as the first progress step.

## 2. Goals

1. Both buttons generate a report and the result is downloadable on Railway.
2. Clicking a button opens a **progress modal** showing live Vietnamese stage descriptions.
3. The modal has an **"Ẩn" (Hide)** button — hiding it does **not** stop generation; it continues in the background.
4. On completion, a **toast notification** appears ("Đã sinh xong báo cáo {ticker}"); on failure, a toast + a clear Vietnamese reason.
5. Generation routes **both** ways: fast render from existing artifacts (~30s) if available, else the full pipeline.
6. For an empty ticker, the full pipeline **actively collects data** and shows the data-search as **sub-steps** (CafeF → BCTC PDF HOSE/HNX/SSC → vnstock → kiểm định). vnstock financials are newly wired in; Vietstock is out of scope (no connector exists).

## 3. Non-goals

- Building a Vietstock financial connector or open-ended "retry until data" scraping (deferred — separate future phase).
- Changing the valuation/data-completeness layer (tracked separately in `improvement.md`).
- Real-time streaming transport (SSE/WebSocket). Polling the existing `/status` endpoint is sufficient.
- Railway persistent volumes. Durable storage is Supabase Storage.

## 4. Current-state facts (verified)

- `runs.current_stage` **is** persisted live: [runner.py:171](../../../backend/harness/runner.py) calls `update_run_state(...)` as the run advances through the 9 `GRAPH_STAGES` (`PREFLIGHT, PLAN, INGEST_AND_VALIDATE, ANALYZE, FORECAST_AND_VALUE, WRITE_REPORT, REVIEW, EXPORT_GATES, PUBLISH` — [graph.py](../../../backend/harness/graph.py)). Update currently happens at stage **end**, lagging the label by one stage.
- `GET /research/{run_id}/status` already returns `current_stage` in `RunStatusResponse` ([schemas.py:41-50](../../../backend/schemas.py)). The frontend `GenerateButton` ignores it today.
- `scripts/generate_fast_report.py::generate_fast_report(ticker, mode)` renders both PDFs from existing run artifacts in ~30s via `render_client_report_to_directory` + `render_report_explanation_to_directory` ([final_report_renderer.py](../../../backend/reporting/final_report_renderer.py)). WeasyPrint/cairo deps are already in the Dockerfile.
- `SupabaseStorageAdapter` ([supabase_adapter.py](../../../backend/storage/supabase_adapter.py)) supports `upload_file`, `download_bytes`, `exists`, and `signed_url` — the last is **restricted to the `exports` bucket** by design ([supabase_adapter.py:159](../../../backend/storage/supabase_adapter.py)), i.e. the intended home for user-facing downloads.
- Ingestion already collects real data: `INGEST_AND_VALIDATE` runs [auto_ingest_official_documents.py](../../../scripts/auto_ingest_official_documents.py) with `channels=["cafef", "pdf"]` — CafeF financial API (`CafeFinanceConnector`) + official PDFs from HOSE/HNX/SSC disclosure connectors + company IR.
- vnstock connectors exist but are **not** wired into auto-ingest: [scripts/connectors/vnstock_finance_connector.py](../../../scripts/connectors/vnstock_finance_connector.py) (+ price, company). Used today for market snapshot only.
- No frontend toast/notification system and no React context exist yet. `EvalModal` ([EvalModal.tsx](../../../frontend/src/components/eval/EvalModal.tsx)) is the reusable modal pattern. `GenerateButton` ([GenerateButton.tsx](../../../frontend/src/components/reports/GenerateButton.tsx)) is used by `ReportRow` for both labels.

## 5. Architecture (phased)

### Phase 1 — Durable report delivery

- New unit `render_and_store(ticker, run_id) -> StoredReport`: renders the report PDF + explanation PDF (reusing the existing renderer functions), uploads both to Supabase `exports/{ticker}/{ticker}_report.pdf` and `…_explanation.pdf` (upsert).
- Serving endpoints `GET /reports/{ticker}/file/{kind}` and `GET /reports/{ticker}/preview/{page}` read from the `exports` bucket (stream `download_bytes`, or 302 to a `signed_url`), falling back to local `output/` for backward compatibility.
- The full pipeline renders+stores on successful completion via a **post-run hook** (in the orchestrator/executor after the run reaches a publishable state), preserving the PUBLISH stage's "no render, audit-immutable" semantics.

### Phase 2 — Generation routing

- New endpoint `POST /reports/{ticker}/generate`:
  - If `latest_ready_snapshot(ticker)` exists **and** a renderable prior run exists → submit a **fast render** job (background) that calls `render_and_store` against the latest run.
  - Else → launch the **full pipeline** (today's `/research/start` behavior), which renders+stores on completion (Phase 1 hook).
  - Returns `{ run_id, mode }` where `mode ∈ {"fast_render", "full_pipeline"}`.
- Both `GenerateButton` labels ("Sinh báo cáo", "Cập nhật") call this endpoint. "Cập nhật" on a ticker that already has artifacts naturally takes the fast path.

### Phase 3 — Live progress (backend)

- Persist `current_stage` at stage **start** (add an `update_run_state` call at the top of the stage loop in [runner.py](../../../backend/harness/runner.py), before `_run_stage`), so the polled stage reflects the in-progress step.
- **Migration 036:** add `progress_json JSONB` to `research.runs` (nullable) for fine-grained sub-steps.
- `RuntimeStore.update_run_progress(run_id, *, stage, substep, detail)` writes `progress_json`.
- The ingestion path emits sub-step updates as it processes each source: `cafef`, `official_pdf`, `vnstock`, `validate`. A thin progress callback is threaded from the runner's INGEST execution into `auto_ingest` so each source boundary updates `progress_json`.
- Wire the **vnstock financial** channel: add `"vnstock"` to the auto-ingest channels and integrate `vnstock_finance_connector` into `run_pipeline` so financials are pulled in addition to CafeF/PDF.
- Surface a human-readable blocking reason: `RunStatusResponse` gains an optional `blocking_reason: str | None` and `progress: {stage, substep, detail} | None`, derived from the run row.

### Phase 4 — Frontend progress UX

- `GenerationProvider` (React context, mounted app-level): holds a map of in-flight runs `{ runId, ticker, label, status, stage, substep, blockingReason, phase }`; owns the polling loop (continues regardless of modal visibility); exposes `start(ticker, label)`; emits toasts on terminal states. State lives above the modal so **"Ẩn" cannot stop polling**.
- `ProgressModal` (mirrors `EvalModal`): renders the Vietnamese 9-stage stepper with the active stage highlighted; under the active INGEST stage, renders the ingestion sub-line from `progress.substep`. Header has an **"Ẩn"** button that only hides the modal (clears "active modal", keeps the run in the provider). On failure shows the blocking reason.
- `ToastContainer` + `Toast`: lightweight, no new dependency. Success: "Đã sinh xong báo cáo {ticker}". Failure: "{reason}".
- `runStatus.ts`: add `stageLabel(stage)` and `ingestSubLabel(substep)` Vietnamese maps.
- `GenerateButton`: on click → `generation.start(ticker, label)` and open the modal. Both labels behave identically. The row reflects the running state (and offers to reopen the modal while running).

#### Vietnamese stage labels

| Stage | Label |
|-------|-------|
| PREFLIGHT | Kiểm tra điều kiện đầu vào |
| PLAN | Lập kế hoạch phân tích |
| INGEST_AND_VALIDATE | Thu thập & kiểm định dữ liệu tài chính |
| ANALYZE | Phân tích tài chính |
| FORECAST_AND_VALUE | Dự phóng & định giá |
| WRITE_REPORT | Soạn báo cáo |
| REVIEW | Rà soát chất lượng |
| EXPORT_GATES | Kiểm tra cổng xuất bản |
| PUBLISH | Dựng file PDF |

#### Ingestion sub-step labels

| Substep | Label |
|---------|-------|
| cafef | Đang tìm dữ liệu trên CafeF… |
| official_pdf | Đang tải BCTC từ HOSE/HNX/SSC… |
| vnstock | Đang lấy dữ liệu vnstock… |
| validate | Đang kiểm định & đối chiếu số liệu… |

### Phase 5 — Tests

- Backend: `render_and_store` (renders + uploads to `exports`); `/reports/{ticker}/generate` routing (fast vs full based on snapshot/run presence); serving from `exports` with local fallback; `update_run_progress` persistence; stage-start persistence; vnstock channel integration smoke; blocking-reason surfacing.
- Frontend: `stageLabel`/`ingestSubLabel` maps; `GenerationProvider` polling continues after modal hide; toast fires on terminal status; `ProgressModal` renders active stage + ingestion sub-line; failure shows blocking reason. Keep existing `GenerateButton`/`ReportsPage` tests green (adapt to the new trigger).

## 6. Honest failure behavior

For tickers where no source yields ingestible financials, the full pipeline blocks at INGEST/ANALYZE (`snapshot_id_missing`). The modal and toast show e.g. *"Không đủ dữ liệu tài chính để tạo báo cáo cho {ticker}"* — the system never spins forever and never fabricates a report. This honors the project rule against silent fallbacks.

## 7. Operational requirements (Railway)

The full pipeline requires, in the container: `DATABASE_URL` (Supabase host), `OPENAI_API_KEY`, `SUPABASE_URL`, `SUPABASE_SERVICE_ROLE_KEY`; the DB migrated to ≥ `036`; the universe CSV shipped; budget envs (`SOFT_BUDGET_USD`/`HARD_BUDGET_USD`) sufficient. The `exports` bucket must exist (create via `create_private_bucket("exports")` if missing). These are documented for the deploy; the fast-render path needs the same Supabase/storage config but no OpenAI calls.

## 8. Data flow summary

```
Button click
  → POST /reports/{ticker}/generate
      → fast: render_and_store(latest run) ──────────────┐
      → full: launch pipeline                            │
            INGEST (cafef→official_pdf→vnstock→validate) │  (progress_json updated per substep)
            → ANALYZE → FORECAST_AND_VALUE → WRITE_REPORT │
            → REVIEW → EXPORT_GATES → PUBLISH             │
            → post-run hook: render_and_store ────────────┤
  → returns run_id                                        │
Frontend GenerationProvider polls /status (stage+substep+blocking_reason)
  → ProgressModal renders Vietnamese stepper (Ẩn = hide only)
  → terminal: toast; report served from exports/{ticker}/…
```

## 9. Open items intentionally deferred

- Vietstock connector + aggressive multi-source retry.
- Concurrent multi-ticker modal management (provider supports multiple in-flight runs; modal shows one at a time — acceptable for now).
- PDF page-preview (`/preview`) regeneration in the deployed path (kept best-effort/local; primary deliverable is the downloadable PDF).
