# Frontend: Reports Export + Evaluation Dashboard — Design Spec

**Date:** 2026-06-14
**Status:** Approved (design), pending spec review
**Author:** dungtrgnguyen + Claude

## 1. Goal

Build a standalone frontend with two pages on top of the existing FastAPI backend:

1. **Reports page** — browse the 53-ticker pharma universe, download each report PDF and its
   explanation PDF, and trigger generation for tickers that have no report yet.
2. **Evaluation dashboard** — present the 8-layer fail-closed evaluation framework (the structure
   described in `eval/`) as a designed shell driven by mock JSON that matches the real artifact
   schemas. Evaluation logic is built in a later workstream; this page is the framework UI it will
   plug into.

This spec covers the **framework/shell only**. No real evaluation computation is in scope.

## 2. Context

- The repo currently has **no frontend**. Backend is FastAPI (`backend/api.py`) with endpoints
  `POST /research/start`, `GET /research/{run_id}/status`, `GET /research/{run_id}/artifacts`,
  `GET /reports/{run_id}`.
- Reports are produced as PDFs in `output/` (e.g. `DHG_report.pdf`, `DHG_explanation.pdf`,
  `pdf_preview/DHG_report_page_*.png`).
- The 53-ticker universe lives in `config/dataset/universe/pharma_vn_universe.csv`
  (columns: `ticker, company_name, exchange, segment, is_mvp, notes`).
  Segments: pharma 43, healthcare_services 3, medical_equipment 3, medical_distribution 3.
- The evaluation framework is specified across `eval/01..08_*.md` + `eval/README.md`. It is
  explicitly a **multi-layer, fail-closed** framework — not a single quality score. Each layer
  produces one JSON artifact.

## 3. Decisions (locked)

| Decision | Choice |
|---|---|
| Tech stack | Vite + React + TypeScript |
| Report page behavior | Browse + preview + download **and** a "request generation" button calling `/research/start` |
| Dashboard data source | Framework shell + **mock JSON matching the real artifact schemas**, read statically from `frontend/src/mock` + `frontend/src/data/evalFramework.ts` |
| Serving | Vite dev server (`:5173`) proxying to FastAPI (`:8000`) in dev; production build to static `dist/` served by FastAPI |
| API path convention | Client calls backend paths **directly** (`/reports`, `/research/...`). **No `/api` prefix anywhere.** Dev proxy forwards `/reports` and `/research` to `:8000`; prod is same-origin. |
| `run_type` | `full_report` (the only `RunType` enum value, confirmed in `backend/schemas.py`) |
| `/eval/framework` backend endpoint | **Deferred to P1** (when live eval artifacts exist). P0 backend adds only report inventory/file/preview; dashboard is fully frontend-static. |
| Branch | Work on `main` directly (sole developer, no PRs — per project convention) |

## 4. Architecture

```
frontend/                          # new Vite + React + TS app
  index.html
  package.json
  tsconfig.json
  vite.config.ts                   # dev proxy /api -> http://localhost:8000
  vitest.config.ts
  src/
    main.tsx                       # mount + router
    App.tsx                        # top nav shell (2 routes)
    api/client.ts                  # typed fetch wrapper around FastAPI
    api/types.ts                   # shared response types
    data/universe.ts               # 53 tickers (generated from the CSV)
    data/evalFramework.ts          # declarative 8-layer × metrics × thresholds (P0/P1/P2)
    pages/
      ReportsPage.tsx
      EvalDashboardPage.tsx
    components/
      reports/ReportRow.tsx
      reports/ReportFilters.tsx
      reports/PreviewPanel.tsx
      reports/GenerateButton.tsx
      eval/PipelineFlow.tsx        # fail-closed pipeline diagram
      eval/MaturityToggle.tsx      # P0 / P1 / P2
      eval/LayerCard.tsx
      eval/MetricRow.tsx
      eval/StatusPill.tsx
      common/Layout.tsx
    lib/evalStatus.ts              # threshold comparison -> pass | fail | measured_only
    mock/                          # one file per eval artifact, real schema shape
      data_quality.json
      retrieval_eval.json
      financial_eval.json
      citation_eval.json
      agent_eval.json
      report_eval.json
      publication_readiness.json
      observability_eval.json
    styles/                        # design tokens + global css
backend/api.py                     # + report-listing, file-serving, preview endpoints (P0)
backend/reporting/output_inventory.py   # new: scan output/ -> per-ticker report availability
```

### Separation of concerns

- **`data/evalFramework.ts`** is the single declarative source of the dashboard structure: 8 layers,
  each with metrics, each metric with `{ id, label, unit, thresholds: {P0, P1, P2}, comparator,
  artifactPath }`. The page renders entirely from this + a values object.
- **`mock/*.json`** supplies current values in the exact shape of the real artifacts. Later, the live
  workstream replaces the mock loader with a fetch to a real artifact endpoint — `evalFramework.ts`
  and all components stay unchanged.
- **`lib/evalStatus.ts`** is pure: `(metricDef, value, maturity) -> status`. Unit-tested in isolation.
- **Backend `output_inventory.py`** is pure filesystem scanning, separate from `api.py` wiring, so it
  is unit-testable without HTTP.

## 5. Backend additions

All additive; no existing endpoint changes.

### 5.1 `backend/reporting/output_inventory.py`

```python
def scan_report_inventory(output_dir: Path, universe: list[dict]) -> list[ReportInventoryItem]
```

For each universe ticker, report whether `{TICKER}_report.pdf`, `{TICKER}_explanation.pdf`, and any
`pdf_preview/{TICKER}_report_page_*.png` exist, plus file size and mtime. Returns a list aligned to
the universe order.

**Extensibility requirement:** the filename→ticker resolution must be isolated behind a small
internal resolver (e.g. a `_resolve_report_files(ticker, output_dir)` helper returning
`{report, explanation, preview_pages}` paths). The current resolver uses the
`{TICKER}_report.pdf` / `{TICKER}_explanation.pdf` convention. If a later phase introduces an
`artifact_manifest` or `run_id`-based filenames, only this resolver changes — the endpoint shapes and
the entire frontend stay untouched.

`preview_pages` is an **array of integers** (the page numbers actually found on disk), sorted in
**numeric** order, e.g. `[1, 2, 3, 4, 12]` (never lexicographic string order).

### 5.2 New endpoints in `backend/api.py` (P0)

| Method | Path | Returns |
|---|---|---|
| `GET` | `/reports` | `{ items: [{ ticker, company_name, exchange, segment, is_mvp, has_report, has_explanation, preview_pages, report_size, updated_at }] }` |
| `GET` | `/reports/{ticker}/file/{kind}` | Streams a file. `kind ∈ {report, explanation}` → the matching PDF; `404` if absent. `Content-Disposition: inline` so the browser can preview/download. |
| `GET` | `/reports/{ticker}/preview/{page}` | Streams `pdf_preview/{ticker}_report_page_{page}.png`; `404` if absent. |

`ticker` is validated against the universe (reject unknown → 404). Path traversal is prevented by
constructing paths from the validated ticker + a fixed filename pattern only.

Existing endpoints reused as-is: `POST /research/start`, `GET /research/{run_id}/status`.

### 5.3 Deferred to P1 — `GET /eval/framework`

Not built in this phase. When live eval artifacts exist, add a backend endpoint that serves the
8-layer framework + real per-run values, and flip `api/client.ts` from the static-mock source to
this endpoint. Until then, the dashboard reads `frontend/src/data/evalFramework.ts` (structure) +
`frontend/src/mock/*.json` (values) only — single source of truth, no backend duplication.

## 6. Reports page — behavior

- **Header**: universe summary — total 53, segment breakdown chips (pharma 43, healthcare_services 3,
  medical_equipment 3, medical_distribution 3), count with reports vs pending.
- **Filters** (`ReportFilters`): free-text ticker/name search; segment select; exchange select;
  status select (has report / pending); MVP-only toggle.
- **Table** (`ReportRow` per ticker): `ticker · company_name · exchange · segment · MVP badge ·
  status`. Status: `✓ report + explanation`, `◑ report only`, `⏳ pending`.
  Actions: **Preview** (opens `PreviewPanel`), **Download report**, **Download explanation**
  (disabled when absent), **Request generation**.
- **PreviewPanel**: shows preview PNG pages for the ticker (from `/reports/{ticker}/preview/{page}`);
  falls back to embedding the PDF via `<iframe>` of `/reports/{ticker}/file/report` when no PNGs.
- **GenerateButton**: `POST /research/start { ticker, run_type: "full_report",
  objective: "Generate full equity research report for {ticker}" }`, then polls
  `GET /research/{run_id}/status` every few seconds. Status badges map from the **real `RunStatus`
  enum** emitted by the backend (`backend/schemas.py` + `to_public_status`):
  - in-progress: `INIT`, `INGESTING`, `ANALYZING`, `VALUATING`, `SYNTHESIZING`, `AUDITING`
  - terminal success: `PUBLISHED`, `PUBLISHED_DRAFT` → re-fetch `/reports` so the row updates
  - terminal failure: `BLOCKED`, `FAILED` → show failure badge, stop polling

  These sets are defined as named constants derived from the enum, **not hardcoded string literals**
  scattered in JSX. Heavy runs are acknowledged: the button shows a persistent running state and the
  user can navigate away.

## 7. Evaluation dashboard — framework structure

The page renders the 8 layers in fail-closed order, preceded by the pipeline diagram and a maturity
toggle. Each layer is a `LayerCard` containing `MetricRow`s. Each `MetricRow` shows the metric label,
the active-maturity threshold, the current (mock) value, and a `StatusPill`
(`pass` / `fail` / `measured_only`).

### 7.1 Fail-closed pipeline (PipelineFlow)

```
Data reliability → Fact reconciliation → Retrieval & source provenance →
Financial calculation invariants → Agent & narrative → Report quality →
Package validation & auto-exported draft → Human final approval → Client-final render authorization
```

Rule annotated on the diagram: a failed deterministic critical layer cannot be overridden by a high
LLM-judge score downstream.

### 7.2 The 8 layers, metrics, thresholds, and artifact shapes

Thresholds are sourced from `eval/*.md`. `measured_only` means "captured but not yet gating at this
maturity" (used where the P0 column says "Measured only").

**Layer 1 — Data reliability** (`data_quality.json`)
| Metric | P0 threshold | comparator |
|---|---|---|
| Core metric coverage | ≥ 95% | gte |
| Period completeness | 100% | gte |
| Source provenance coverage | 100% | gte |
| Official reconciliation rate | ≥ 95% | gte |
| OCR unresolved rate | 0% | lte |
| Duplicate fact rate | 0% | lte |

Artifact shape:
```json
{ "ticker": "DHG", "run_id": "string",
  "core_metric_coverage": 0.0, "period_completeness": 0.0,
  "provenance_coverage": 0.0, "official_reconciliation_rate": 0.0,
  "ocr_unresolved_rate": 0.0, "duplicate_fact_rate": 0.0,
  "freshness_days": 0, "blocking_issues": [] }
```

**Layer 2 — RAG & evidence** (`retrieval_eval.json`)
| Metric | P0 | P1 | comparator |
|---|---|---|---|
| Hit-rate@5 | measured_only | ≥ 90% | gte |
| MRR@5 | measured_only | ≥ 0.80 | gte |
| Context precision | measured_only | ≥ 0.85 | gte |
| Context recall | measured_only | ≥ 0.85 | gte |
| Faithfulness | measured_only | ≥ 0.85 (P1) / 0.90 (P2) | gte |
| Response relevancy | measured_only | ≥ 0.85 | gte |

Artifact shape: per `eval/02` §5 (`ragas_scores`, `golden_scores`, `blocking_failures`).

**Layer 3 — Financial calculation** (`financial_eval.json`)
Invariants (all Critical, target 0 failures): net debt, EPS, BS balance, FCFF, FCFE, EV-to-equity,
target price, Gordon growth (`discount_rate > terminal_growth`), sensitivity matrix varies,
sensitivity base cell matches target, recommendation matches upside policy.
Acceptance: formula unit tests 100%, golden valuation drift 0% out of tolerance, critical invariant
failures 0, missing FCFE/blend sensitivity in final 0.
Artifact shape:
```json
{ "ticker": "DHG", "run_id": "string",
  "invariants": [ { "id": "net_debt", "severity": "critical", "passed": true, "detail": "" } ],
  "critical_failures": 0, "golden_drift_out_of_tolerance": 0,
  "missing_traces": [], "decision": "pass|block" }
```

**Layer 4 — Citation & provenance** (`citation_eval.json`)
| Metric | final threshold | comparator |
|---|---|---|
| Quantitative citation coverage | 100% | gte |
| Citation key resolution | 100% | gte |
| Source ID validity | 100% | gte |
| Official source coverage (material quant. claims) | 100% | gte |
| Numeric mismatch rate above tolerance | 0% | lte |
| Tier-3-only material claims | 0 | lte |
| Generic citation labels | 0 | lte |
| Catalyst events without evidence span | 0 | lte |

Artifact shape: per `eval/04` §5 (`citation_coverage_ratio`, `source_tier_counts`,
`official_source_coverage`, `numeric_mismatches`, `generic_citations`, `export_blocked`).

**Layer 5 — Agent workflow & LLM judge** (`agent_eval.json`)
| Metric | threshold | comparator |
|---|---|---|
| Tool permission compliance | 100% | gte |
| Output schema validity | 100% | gte |
| Role adherence | ≥ 0.90 | gte |
| Groundedness | ≥ 0.90 (final) | gte |
| No unauthorized financial calculation | 100% | gte |
| Task completion | ≥ 0.85 | gte |
| Plan adherence | ≥ 0.85 | gte |
| Critic issue recall (seeded failures) | ≥ 90% | gte |

Judge rubric dimensions (display-only, 7): evidence discipline, financial restraint, company
specificity, materiality, risk balance, citation integrity, professional tone.
Artifact shape:
```json
{ "ticker": "DHG", "run_id": "string",
  "tool_permission_compliance": 1.0, "schema_validity": 1.0,
  "role_adherence": 0.0, "groundedness": 0.0, "no_unauthorized_calc": 1.0,
  "task_completion": 0.0, "plan_adherence": 0.0, "critic_issue_recall": 0.0,
  "rubric_scores": {}, "blocking_failures": [] }
```

**Layer 6 — Report quality** (`report_eval.json`)
Blocking conditions (Critical): Report quality score < 85, any failed deterministic finance gate,
recommendation visible before approval, target price from blocked valuation, snapshot mismatch,
missing evidence/formula trace, PDF rendered from candidate model as final, missing final approval,
publishable model not locked, Report-quality warning treated as final pass, post-render audit failed.
Decision rule: `allow_export` if score ≥ 85 and no failed gate; `draft_only` if ≥ 70 with fails;
else `block_export`.
Artifact shape: per `eval/06` §5 (`rubric`, `score`, `decision`, `failed_gates`, `section_scores`,
`report_artifacts`, `publication_readiness`).

**Layer 7 — Observability, cost, latency** (`observability_eval.json`)
| Metric | warning threshold | comparator |
|---|---|---|
| Full run duration | > baseline p95 + 30% | gt-warn |
| LLM retry rate | > 5% | gt-warn |
| Retrieval fallback rate | > 20% | gt-warn |
| OCR failure rate (material) | > 5% | gt-warn |
| Artifact upload failures (final) | > 0 | gt-warn |
| PDF render failures (final) | > 0 | gt-warn |
| Cost per full report | > soft budget | gt-warn |

Artifact shape: per `eval/07` §4 (`duration_seconds`, `stage_durations`, `llm{...}`,
`retrieval{...}`, `blocking_gate_categories`, `publication{...}`, `trace_url`).

**Layer 8 — Rollout & CI** (display-only; no per-run artifact)
Two tables rendered from `evalFramework.ts`:
- **CI gate matrix**: `unit-core`, `evaluation-gates`, `finance-regression`, `report-render-smoke`
  (block merge); `rag-golden`, `llm-judge-offline` (warn→block); `integration-db` (scheduled).
- **Acceptance thresholds by maturity** (P0/P1/P2): data critical failures 0/0/0; finance critical
  failures 0/0/0; citation coverage 100%/100%/100%; FPTS ≥85/≥85/≥90; RAG hit-rate@5
  measured/≥90%/≥95%; faithfulness measured/≥0.85/≥0.90; role adherence measured/≥0.85/≥0.90;
  cost baseline/≤+15%/budgeted.

`publication_readiness.json` (cross-cutting, shown as a banner on the dashboard): `passed`,
`run_approval`, `final_approval`, `locked_publishable_model`, `package_gate`, `report_quality_allow_export`,
`snapshot_match`, `blocking_reasons[]`.

### 7.3 Maturity toggle

`MaturityToggle` selects `P0 | P1 | P2`. `lib/evalStatus.ts` picks the threshold column for the active
maturity. A metric with no threshold at that maturity (e.g. RAG at P0) renders as `measured_only`.

## 7b. API path convention & serving

To avoid any `/api`-vs-`/reports` mismatch (a single, consistent rule):

- The frontend client calls backend paths **directly**: `/reports`, `/reports/{t}/file/{kind}`,
  `/reports/{t}/preview/{p}`, `/research/start`, `/research/{id}/status`. **No `/api` prefix.**
- **Dev:** `vite.config.ts` `server.proxy` forwards `/reports` and `/research` to
  `http://localhost:8000` (no path rewrite — paths are identical on both sides).
- **Prod:** FastAPI serves the built `dist/` via `StaticFiles` mounted at `/` with an SPA fallback,
  and the same `/reports` + `/research` routes are same-origin. API routes are registered before the
  static mount so they take precedence.
- `api/client.ts` keeps a single `API_BASE` constant (default `""` = same-origin) for future
  flexibility, but ships empty so dev (proxy) and prod (same-origin) both work without `/api`.

## 8. Design language (frontend-design)

- **Language: 100% Vietnamese UI chrome.** All labels, headings, buttons, status text in Vietnamese.
- **Font: Open Sans** as the primary UI typeface (full Vietnamese diacritics support — no broken
  glyphs). Load the Vietnamese subset (self-hosted `@fontsource/open-sans` preferred over a CDN so it
  works offline; `latin` + `vietnamese` subsets). Use a monospace font only for numeric metric values.
- **Base font size bumped up** for readability: root `font-size: 17px` (instead of the 16px default),
  with a clear modular type scale on top. Tables/metric values stay legible at this larger base.
- Clean, scientific, data-dense but breathable. Strong typographic hierarchy; tabular/monospace
  numerals for all metric values; restrained palette with semantic status colors (pass / fail /
  measured / warn). Avoid generic AI gradient aesthetics.
- Status pills and the fail-closed flow diagram are the signature visual elements. The dashboard
  reads like an instrument panel, not a marketing page.
- Specific visual direction (typography scale, palette, spacing) is decided during implementation
  using the frontend-design skill.

## 9. Testing

- **Frontend (Vitest + React Testing Library):**
  - `lib/evalStatus.ts` — pass/fail/measured_only across comparators and maturities.
  - `ReportFilters` filtering logic; `ReportRow` action enablement by status.
  - `LayerCard`/`MetricRow` render threshold + status from a framework def + values.
  - `api/client.ts` source toggle (mock vs live) with a mocked fetch.
- **Backend (pytest):**
  - `output_inventory.scan_report_inventory` over a temp dir with/without files.
  - `GET /reports` shape and counts; `GET /reports/{ticker}/file/{kind}` 200 + 404 + unknown-ticker
    404 + traversal rejection; `GET /eval/framework` shape.

## 10. Out of scope

- Real evaluation computation / wiring live artifacts (separate later workstream).
- Auth, multi-user, persistence of UI state.
- Triggering batch generation of all 53 at once from the UI (single-ticker request only).
- Editing reports or eval data from the UI.

## 11. Success criteria

1. `cd frontend && npm install && npm run dev` serves both pages; `npm run build` produces `dist/`.
2. Reports page lists all 53 tickers with correct status from `output/`, downloads existing PDFs,
   previews via PNGs/PDF, and can request generation with live progress.
3. Dashboard renders all 8 layers with metrics, thresholds, mock values, status pills, the
   fail-closed pipeline diagram, the maturity toggle, the CI gate matrix, and the maturity threshold
   table — all driven declaratively so live data is a later data-source swap.
4. New backend endpoints are additive and unit-tested; existing endpoints unchanged.
5. Frontend and backend test suites pass.
